#!/bin/bash

# Claude Mythos — AI Digital Marketing Agency
# Local Startup Script for MacBook

echo "🏰 Claude Mythos — Launching Your AI Agency..."
echo ""

# Colors
GOLD='\033[1;33m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Check Docker
echo "[1/5] Checking Docker..."
if ! docker info > /dev/null 2>&1; then
    echo "❌ Docker is not running. Please start Docker Desktop and try again."
    exit 1
fi
echo "✅ Docker is running"

# Check .env file
echo ""
echo "[2/5] Checking configuration..."
if [ ! -f .env ]; then
    echo "⚠️  No .env file found. Creating from template..."
    cp backend/.env.example .env
    echo "✅ Created .env file — please edit it with your API keys"
    echo "   Run: nano .env"
    exit 1
fi
echo "✅ Configuration found"

# Build and start
echo ""
echo "[3/5] Building services..."
docker-compose build

echo ""
echo "[4/5] Starting services..."
docker-compose up -d

echo ""
echo "[5/5] Checking health..."
sleep 5
if curl -s http://localhost:8000/health > /dev/null 2>&1; then
    echo "✅ Backend is healthy"
else
    echo "⚠️  Backend may still be starting..."
fi

echo ""
echo "═══════════════════════════════════════════"
echo "${GOLD}  🏰 Claude Mythos is ONLINE${NC}"
echo "═══════════════════════════════════════════"
echo ""
echo "${CYAN}Dashboard:${NC}  http://localhost:3000"
echo "${CYAN}API:${NC}        http://localhost:8000"
echo "${CYAN}Health:${NC}     http://localhost:8000/health"
echo ""
echo "${GREEN}Your 23 AI employees are ready for duty.${NC}"
echo ""
echo "Commands:"
echo "  ./start.sh       — Start the agency"
echo "  ./stop.sh        — Stop the agency"
echo "  docker-compose logs -f backend  — View backend logs"
echo ""
