#!/bin/bash

echo "🏰 Shutting down Claude Mythos..."
docker-compose down
echo "✅ Agency stopped. Your AI employees are resting."
