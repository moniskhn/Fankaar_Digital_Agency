#!/bin/bash
# Claude Mythos - DigitalOcean Droplet Deployment Script
# Creates a $6/month droplet and deploys Claude Mythos with Docker + Caddy

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# Configuration
DROPLET_NAME="${DO_DROPLET_NAME:-claude-mythos}"
REGION="${DO_REGION:-nyc1}"
SIZE="${DO_SIZE:-s-1vcpu-1gb}"  # $6/month
IMAGE="ubuntu-24-04-x64"
SSH_KEY_NAME="${DO_SSH_KEY_NAME:-}"
DOMAIN="${DOMAIN:-}"

echo ""
echo -e "${BOLD}  Claude Mythos - DigitalOcean Deployment${NC}"
echo -e "  ${CYAN}Full control VPS with Docker + Caddy + SSL${NC}"
echo ""

# ── Check doctl ────────────────────────────────────────────────

if ! command -v doctl &> /dev/null; then
    echo -e "${RED} doctl not found. Installing...${NC}"
    if [[ "$OSTYPE" == "darwin"* ]]; then
        brew install doctl
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        curl -sL https://github.com/digitalocean/doctl/releases/latest/download/doctl-$(uname -s)-$(uname -m).tar.gz | tar -xzv -C /usr/local/bin
    fi
    echo -e "${YELLOW} Run 'doctl auth init' to authenticate${NC}"
    exit 1
fi

if ! doctl account get &> /dev/null; then
    echo -e "${RED} Not authenticated. Run: doctl auth init${NC}"
    exit 1
fi

echo -e "${GREEN} doctl authenticated${NC}"

# ── Create droplet ─────────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 1/6: Creating Droplet${NC}"

if doctl compute droplet get "$DROPLET_NAME" &> /dev/null; then
    echo -e "${GREEN} Droplet '$DROPLET_NAME' already exists${NC}"
    DROPLET_IP=$(doctl compute droplet get "$DROPLET_NAME" --format PublicIPv4 --no-header)
else
    echo "  Creating droplet '$DROPLET_NAME' in $REGION..."
    echo "  Size: $SIZE (~$6/month)"
    echo "  OS: Ubuntu 24.04 LTS"

    SSH_KEY_ARG=""
    if [ -n "$SSH_KEY_NAME" ]; then
        SSH_KEY_ID=$(doctl compute ssh-key list --format ID,Name --no-header | grep "$SSH_KEY_NAME" | awk '{print $1}' | head -1)
        if [ -n "$SSH_KEY_ID" ]; then
            SSH_KEY_ARG="--ssh-keys $SSH_KEY_ID"
        fi
    fi

    doctl compute droplet create "$DROPLET_NAME" \
        --region "$REGION" \
        --size "$SIZE" \
        --image "$IMAGE" \
        --enable-monitoring \
        --enable-ipv6 \
        --tag-name claude-mythos \
        --user-data-file /dev/stdin \
        --wait \
        $SSH_KEY_ARG \
        --format ID,Name,PublicIPv4,Status \
        << 'CLOUD_INIT'
#!/bin/bash
set -e

# Log output
exec > /var/log/claude-mythos-setup.log 2>&1
set -x

echo "=== Starting Claude Mythos setup ==="

# Update system
apt-get update && apt-get upgrade -y

# Install Docker
curl -fsSL https://get.docker.com | sh
usermod -aG docker root
systemctl enable docker
systemctl start docker

# Install Docker Compose
DOCKER_COMPOSE_VERSION=$(curl -s https://api.github.com/repos/docker/compose/releases/latest | grep '"tag_name"' | cut -d'"' -f4)
curl -L "https://github.com/docker/compose/releases/download/${DOCKER_COMPOSE_VERSION}/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

# Install Caddy
apt-get install -y debian-keyring debian-archive-keyring apt-transport-https
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list
apt-get update && apt-get install -y caddy

# Install jq and curl
apt-get install -y jq curl git ufw fail2ban

echo "=== Base setup complete ==="
CLOUD_INIT

    DROPLET_IP=$(doctl compute droplet get "$DROPLET_NAME" --format PublicIPv4 --no-header)
    echo -e "${GREEN} Droplet created: $DROPLET_IP${NC}"
fi

echo ""
echo -e "  ${BOLD}Droplet IP:${NC} ${CYAN}${DROPLET_IP}${NC}"

# ── Wait for SSH ───────────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 2/6: Waiting for SSH access${NC}"
for i in {1..30}; do
    if ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 "root@${DROPLET_IP}" "echo ready" &> /dev/null; then
        echo -e "${GREEN} SSH ready${NC}"
        break
    fi
    echo "  Attempt $i/30..."
    sleep 10
done

# ── Deploy application ─────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 3/6: Deploying Claude Mythos${NC}"

# Create deployment script on server
DEPLOY_SCRIPT=$(cat << 'DEPLOY_EOF'
#!/bin/bash
set -e

APP_DIR="/opt/claude-mythos"
mkdir -p "$APP_DIR" && cd "$APP_DIR"

# Create docker-compose.override.yml for production
cat > docker-compose.prod.yml << 'COMPOSE'
version: "3.8"
services:
  backend:
    build:
      context: .
      dockerfile: Dockerfile.backend
    container_name: mythos-backend
    restart: unless-stopped
    environment:
      - APP_ENV=production
      - DATABASE_PATH=/app/data/mythos.db
      - API_HOST=0.0.0.0
      - API_PORT=8000
      - WORKERS=2
      - CORS_ORIGINS=*
    volumes:
      - mythos-data:/app/data
    networks:
      - mythos-network
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "5"
  
  frontend:
    image: nginx:1.25-alpine
    container_name: mythos-frontend
    restart: unless-stopped
    volumes:
      - ./frontend/dist:/usr/share/nginx/html:ro
      - ./nginx.prod.conf:/etc/nginx/conf.d/default.conf:ro
    networks:
      - mythos-network
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

volumes:
  mythos-data:
networks:
  mythos-network:
COMPOSE

# Create Caddyfile
cat > Caddyfile << 'CADDY'
:80 {
    root * /opt/claude-mythos/frontend/dist
    file_server
    try_files {path} /index.html

    reverse_proxy /api/* localhost:8000
    reverse_proxy /webhook/* localhost:8000
    reverse_proxy /docs localhost:8000
    reverse_proxy /health localhost:8000

    encode gzip zstd
    header {
        X-Frame-Options "SAMEORIGIN"
        X-Content-Type-Options "nosniff"
        X-XSS-Protection "1; mode=block"
        Referrer-Policy "strict-origin-when-cross-origin"
    }
}
CADDY

# Create systemd service for Caddy
cat > /etc/systemd/system/caddy-mythos.service << 'SERVICE'
[Unit]
Description=Caddy Reverse Proxy for Claude Mythos
After=network.target

[Service]
Type=notify
ExecStart=/usr/bin/caddy run --config /opt/claude-mythos/Caddyfile
ExecReload=/usr/bin/caddy reload --config /opt/claude-mythos/Caddyfile
TimeoutStopSec=5s
LimitNOFILE=1048576
LimitNPROC=512
PrivateTmp=true
ProtectSystem=full
AmbientCapabilities=CAP_NET_BIND_SERVICE

[Install]
WantedBy=multi-user.target
SERVICE

systemctl daemon-reload
systemctl enable caddy-mythos

# Create startup script
cat > /opt/claude-mythos/start.sh << 'START'
#!/bin/bash
cd /opt/claude-mythos
docker-compose -f docker-compose.prod.yml up -d
systemctl start caddy-mythos
echo "Claude Mythos started"
START
chmod +x /opt/claude-mythos/start.sh

cat > /opt/claude-mythos/stop.sh << 'STOP'
#!/bin/bash
cd /opt/claude-mythos
docker-compose -f docker-compose.prod.yml down
systemctl stop caddy-mythos
echo "Claude Mythos stopped"
STOP
chmod +x /opt/claude-mythos/stop.sh

echo "=== Deployment files created ==="
DEPLOY_EOF
)

# Copy and execute deployment script on server
echo "  Uploading deployment configuration..."
echo "$DEPLOY_SCRIPT" | ssh -o StrictHostKeyChecking=no "root@${DROPLET_IP}" "bash -s"

# ── Firewall setup ─────────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 4/6: Configuring Firewall${NC}"

ssh -o StrictHostKeyChecking=no "root@${DROPLET_IP}" << 'FIREWALL'
ufw --force reset
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp   # SSH
ufw allow 80/tcp   # HTTP
ufw allow 443/tcp  # HTTPS
ufw --force enable
echo "Firewall configured"
FIREWALL

# ── Fail2ban ───────────────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 5/6: Configuring Fail2ban${NC}"

ssh -o StrictHostKeyChecking=no "root@${DROPLET_IP}" << 'FAIL2BAN'
cat > /etc/fail2ban/jail.local << 'JAIL'
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3
JAIL

systemctl enable fail2ban
systemctl restart fail2ban
echo "Fail2ban configured"
FAIL2BAN

# ── Domain setup (optional) ────────────────────────────────────

if [ -n "$DOMAIN" ]; then
    echo ""
    echo -e "${BOLD} Step 6/6: Domain Configuration${NC}"
    echo -e "  ${YELLOW}Update your DNS:${NC}"
    echo -e "  A record: ${DOMAIN} -> ${DROPLET_IP}"
    echo -e "  A record: www.${DOMAIN} -> ${DROPLET_IP}"
    echo ""
    
    # Update Caddyfile with domain
    ssh -o StrictHostKeyChecking=no "root@${DROPLET_IP}" << EOF
cat > /opt/claude-mythos/Caddyfile << CADDY
cmythos.tech www.cmythos.tech {
    root * /opt/claude-mythos/frontend/dist
    file_server
    try_files {path} /index.html

    reverse_proxy /api/* localhost:8000
    reverse_proxy /webhook/* localhost:8000
    reverse_proxy /docs localhost:8000
    reverse_proxy /health localhost:8000

    encode gzip zstd
    header {
        X-Frame-Options "SAMEORIGIN"
        X-Content-Type-Options "nosniff"
        X-XSS-Protection "1; mode=block"
        Referrer-Policy "strict-origin-when-cross-origin"
    }

    tls {
        protocols tls1.2 tls1.3
    }
}
CADDY
systemctl restart caddy-mythos
EOF
fi

# ── Summary ────────────────────────────────────────────────────

echo ""
echo "═══════════════════════════════════════════════════════════"
echo -e "  ${GREEN}${BOLD}DigitalOcean deployment complete!${NC}"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo -e "  ${BOLD}Droplet:${NC}     ${DROPLET_NAME} (${DROPLET_IP})"
echo -e "  ${BOLD}SSH Access:${NC}  ssh root@${DROPLET_IP}"
echo -e "  ${BOLD}App URL:${NC}     http://${DROPLET_IP}"
if [ -n "$DOMAIN" ]; then
    echo -e "  ${BOLD}Domain:${NC}      https://${DOMAIN}"
fi
echo ""
echo -e "  ${BOLD}Management Commands:${NC}"
echo "    ssh root@${DROPLET_IP} 'cd /opt/claude-mythos && docker-compose -f docker-compose.prod.yml ps'"
echo "    ssh root@${DROPLET_IP} 'docker logs mythos-backend'"
echo "    ssh root@${DROPLET_IP} 'systemctl status caddy-mythos'"
echo ""
echo -e "  ${BOLD}Next Steps:${NC}"
echo "    1. Copy your .env file: scp .env root@${DROPLET_IP}:/opt/claude-mythos/"
echo "    2. Start services: ssh root@${DROPLET_IP} '/opt/claude-mythos/start.sh'"
echo "    3. Set up domain DNS if needed"
echo ""
echo -e "  ${BOLD}Costs:${NC} ~$6/month (1 vCPU, 1GB RAM, 25GB SSD)"
echo ""
