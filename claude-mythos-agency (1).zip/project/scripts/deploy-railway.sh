#!/bin/bash
# Claude Mythos - Railway.app Deployment Script
# Quick deploy to Railway.app with persistent SQLite storage

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

echo ""
echo -e "${BOLD}  Claude Mythos - Railway.app Deployment${NC}"
echo -e "  ${CYAN}Quick deploy with auto-scaling${NC}"
echo ""

# ── Check CLI ──────────────────────────────────────────────────

if ! command -v railway &> /dev/null; then
    echo -e "${RED} Railway CLI not found. Installing...${NC}"
    npm install -g @railway/cli
fi

if ! railway whoami &> /dev/null; then
    echo -e "${YELLOW} Please log in to Railway:${NC}"
    railway login
fi

echo -e "${GREEN} Railway CLI ready${NC}"

# ── Link or create project ─────────────────────────────────────

echo ""
echo -e "${BOLD} Step 1: Project Setup${NC}"

if [ ! -f .railway/config.json ] 2>/dev/null; then
    echo "  Initializing new Railway project..."
    railway init --name "claude-mythos"
else
    echo -e "${GREEN} Project already linked${NC}"
fi

# ── Set environment variables ──────────────────────────────────

echo ""
echo -e "${BOLD} Step 2: Environment Variables${NC}"

set_env() {
    local key="$1"
    local value="${2:-}"
    local is_secret="${3:-false}"
    if [ -n "$value" ]; then
        if [ "$is_secret" = "true" ]; then
            railway variables --set "$key=$value" 2>/dev/null || true
        else
            railway variables --set "$key=$value" 2>/dev/null || true
        fi
        echo -e "    ${GREEN}Set${NC} $key"
    fi
}

# Load from .env if present
if [ -f .env ]; then
    source .env
    echo -e "  ${GREEN}Loaded variables from .env${NC}"
fi

echo "  Setting required variables..."
set_env "APP_ENV" "production"
set_env "DATABASE_PATH" "/app/data/mythos.db"
set_env "API_HOST" "0.0.0.0"
set_env "API_PORT" "8000"
set_env "LOG_LEVEL" "INFO"
set_env "CORS_ORIGINS" "*"
set_env "AGENCY_NAME" "${AGENCY_NAME:-Claude Mythos}"
set_env "LLM_PROVIDER" "${LLM_PROVIDER:-anthropic}"
set_env "ANTHROPIC_MODEL" "${ANTHROPIC_MODEL:-claude-3-5-sonnet-20241022}"

echo "  Setting secrets..."
set_env "ANTHROPIC_API_KEY" "${ANTHROPIC_API_KEY:-}" "true"
set_env "OPENAI_API_KEY" "${OPENAI_API_KEY:-}" "true"
set_env "TWILIO_ACCOUNT_SID" "${TWILIO_ACCOUNT_SID:-}" "true"
set_env "TWILIO_AUTH_TOKEN" "${TWILIO_AUTH_TOKEN:-}" "true"
set_env "TWILIO_WHATSAPP_NUMBER" "${TWILIO_WHATSAPP_NUMBER:-}" "true"
set_env "OWNER_WHATSAPP_NUMBER" "${OWNER_WHATSAPP_NUMBER:-}" "true"

echo -e "${GREEN} Variables configured${NC}"

# ── Deploy ─────────────────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 3: Deploying${NC}"
railway up --detach

# ── Add volume (manual step reminder) ──────────────────────────

echo ""
echo -e "${YELLOW} Step 4: IMPORTANT - Add Persistent Volume${NC}"
echo "  Railway restarts containers, so SQLite data needs a volume:"
echo ""
echo -e "  ${CYAN}1. Go to Railway Dashboard > Your Project > Volumes${NC}"
echo -e "  ${CYAN}2. Click 'New Volume'${NC}"
echo -e "  ${CYAN}3. Mount path: /app/data${NC}"
echo -e "  ${CYAN}4. Size: 1GB (enough for SQLite)${NC}"
echo -e "  ${CYAN}5. Click 'Create'${NC}"
echo ""

# ── Summary ────────────────────────────────────────────────────

echo ""
echo "═══════════════════════════════════════════════════════════"
echo -e "  ${GREEN}${BOLD}Railway deployment complete!${NC}"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo -e "  ${BOLD}Dashboard:${NC}  ${CYAN}https://railway.app/dashboard${NC}"
echo -e "  ${BOLD}Commands:${NC}"
echo "    railway logs          - View logs"
echo "    railway status        - Check status"
echo "    railway variables     - Manage variables"
echo ""
echo -e "  ${BOLD}Costs:${NC} ~$5/month (512MB RAM, auto-sleep on free tier)"
echo "         Start from $0 with free trial + $5 credit"
echo ""
