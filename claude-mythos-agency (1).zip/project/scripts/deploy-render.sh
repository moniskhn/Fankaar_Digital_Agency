#!/bin/bash
# Claude Mythos - Render.com Deployment Script
# Deploy via Render Blueprint for automated setup

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

echo ""
echo -e "${BOLD}  Claude Mythos - Render.com Deployment${NC}"
echo -e "  ${CYAN}Blueprint deployment with free tier support${NC}"
echo ""

# ── Prerequisites ──────────────────────────────────────────────

echo -e "${BOLD}Step 1: Prerequisites${NC}"
echo ""
echo -e "  ${YELLOW}Render.com deploys directly from Git:${NC}"
echo ""
echo -e "  ${CYAN}1. Push your code to GitHub/GitLab${NC}"
echo -e "  ${CYAN}2. Go to https://dashboard.render.com/blueprints${NC}"
echo -e "  ${CYAN}3. Click 'New Blueprint Instance'${NC}"
echo -e "  ${CYAN}4. Connect your repository${NC}"
echo -e "  ${CYAN}5. Render reads render.yaml and creates services${NC}"
echo ""

# ── Alternative: Manual deploy via dashboard ───────────────────

echo -e "${BOLD}Alternative: Manual Dashboard Deploy${NC}"
echo ""
echo -e "  ${CYAN}Backend Service:${NC}"
echo "    1. New > Web Service"
echo "    2. Connect repo, select Docker runtime"
echo "    3. Set Dockerfile path: Dockerfile.backend"
echo "    4. Add environment variables (see below)"
echo "    5. Add disk: mount=/app/data, size=1GB"
echo "    6. Health check path: /health"
echo ""
echo -e "  ${CYAN}Frontend Static Site:${NC}"
echo "    1. New > Static Site"
echo "    2. Build command: cd frontend && npm install && npm run build"
echo "    3. Publish directory: frontend/dist"
echo "    4. Add rewrite rule: /* -> /index.html"
echo ""

# ── Environment Variables ──────────────────────────────────────

echo -e "${BOLD}Required Environment Variables:${NC}"
echo ""
echo "  APP_ENV=production"
echo "  DATABASE_PATH=/app/data/mythos.db"
echo "  API_HOST=0.0.0.0"
echo "  API_PORT=8000"
echo "  LOG_LEVEL=INFO"
echo "  CORS_ORIGINS=*"
echo "  LLM_PROVIDER=anthropic"
echo ""
echo -e "${BOLD}Secret Variables (set in dashboard):${NC}"
echo ""
echo "  ANTHROPIC_API_KEY=sk-ant-..."
echo "  OPENAI_API_KEY=sk-...        (optional)"
echo "  TWILIO_ACCOUNT_SID=AC..."
echo "  TWILIO_AUTH_TOKEN=..."
echo "  TWILIO_WHATSAPP_NUMBER=+1415..."
echo "  OWNER_WHATSAPP_NUMBER=+971..."
echo ""

# ── Summary ────────────────────────────────────────────────────

echo ""
echo "═══════════════════════════════════════════════════════════"
echo -e "  ${GREEN}${BOLD}Render Deployment Guide${NC}"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo -e "  ${BOLD}Free Tier:${NC}"
echo "    - Web Service: Free (sleeps after 15min inactivity)"
echo "    - Static Site: Free (always on)"
echo "    - Disk: Free (up to 1GB)"
echo ""
echo -e "  ${BOLD}Paid Tier:${NC}"
echo "    - Starter: $7/month (always on, 512MB RAM)"
echo "    - Standard: $25/month (2GB RAM)"
echo ""
echo -e "  ${BOLD}URLs after deploy:${NC}"
echo "    Backend: https://claude-mythos-backend.onrender.com"
echo "    Frontend: https://claude-mythos-frontend.onrender.com"
echo ""
echo -e "  ${YELLOW}Note: Free tier web services sleep after 15min inactivity.${NC}"
echo -e "  ${YELLOW}First request after sleep takes ~30s to wake up.${NC}"
echo ""
