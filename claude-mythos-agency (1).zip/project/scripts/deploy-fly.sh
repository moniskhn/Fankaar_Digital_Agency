#!/bin/bash
# Claude Mythos - Fly.io One-Command Deployment
# Fly.io is the RECOMMENDED platform - simple, affordable, global

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

APP_NAME="${FLY_APP_NAME:-claude-mythos}"
REGION="${FLY_REGION:-ams}"

echo ""
echo -e "${BOLD}  Claude Mythos - Fly.io Deployment${NC}"
echo -e "  ${CYAN}The simplest way to deploy your AI agency${NC}"
echo ""

# ── Pre-flight checks ──────────────────────────────────────────

if ! command -v flyctl &> /dev/null; then
    echo -e "${RED} flyctl not found. Installing...${NC}"
    if [[ "$OSTYPE" == "darwin"* ]]; then
        brew install flyctl
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        curl -L https://fly.io/install.sh | sh
        export PATH="$HOME/.fly/bin:$PATH"
    else
        echo -e "${RED} Please install flyctl manually: https://fly.io/docs/hands-on/install-flyctl/${NC}"
        exit 1
    fi
fi

if ! flyctl auth whoami &> /dev/null; then
    echo -e "${YELLOW} Please log in to Fly.io:${NC}"
    flyctl auth login
fi

echo -e "${GREEN} Fly.io CLI ready ($(flyctl version | head -1))${NC}"

# ── Check for required secrets ─────────────────────────────────

echo ""
echo -e "${BOLD} Step 1/5: Environment Configuration${NC}"

if [ -f .env ]; then
    source .env
    echo -e "${GREEN} Loaded environment from .env${NC}"
else
    echo -e "${YELLOW} No .env file found. You'll need to set secrets manually.${NC}"
fi

if [ -z "${ANTHROPIC_API_KEY:-}" ] && [ -z "${OPENAI_API_KEY:-}" ]; then
    echo -e "${YELLOW} No LLM API key found. You must set ANTHROPIC_API_KEY or OPENAI_API_KEY.${NC}"
fi

# ── Create volume if not exists ────────────────────────────────

echo ""
echo -e "${BOLD} Step 2/5: Creating Persistent Volume${NC}"

if ! flyctl volumes list --app "$APP_NAME" 2>/dev/null | grep -q "mythos_data"; then
    echo "  Creating volume 'mythos_data' in $REGION..."
    flyctl volumes create mythos_data --app "$APP_NAME" --region "$REGION" --size 3 --yes || true
else
    echo -e "${GREEN} Volume 'mythos_data' already exists${NC}"
fi

# ── Launch or deploy ───────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 3/5: Deploying Application${NC}"

if flyctl status --app "$APP_NAME" &> /dev/null; then
    echo "  App exists, deploying updates..."
    flyctl deploy --app "$APP_NAME" --region "$REGION"
else
    echo "  First-time launch..."
    flyctl launch --name "$APP_NAME" --region "$REGION" --no-deploy --copy-config
    flyctl deploy --app "$APP_NAME"
fi

# ── Set secrets ────────────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 4/5: Setting Secrets${NC}"

SECRETS_SET=0

set_secret() {
    local key="$1"
    local value="${2:-}"
    if [ -n "$value" ]; then
        echo "  Setting $key..."
        flyctl secrets set "$key=$value" --app "$APP_NAME" --stage
        SECRETS_SET=$((SECRETS_SET + 1))
    fi
}

set_secret "ANTHROPIC_API_KEY" "${ANTHROPIC_API_KEY:-}"
set_secret "OPENAI_API_KEY" "${OPENAI_API_KEY:-}"
set_secret "TWILIO_ACCOUNT_SID" "${TWILIO_ACCOUNT_SID:-}"
set_secret "TWILIO_AUTH_TOKEN" "${TWILIO_AUTH_TOKEN:-}"
set_secret "TWILIO_WHATSAPP_NUMBER" "${TWILIO_WHATSAPP_NUMBER:-}"
set_secret "OWNER_WHATSAPP_NUMBER" "${OWNER_WHATSAPP_NUMBER:-}"

if [ "$SECRETS_SET" -gt 0 ]; then
    echo "  Deploying with secrets..."
    flyctl deploy --app "$APP_NAME"
fi

echo -e "${GREEN} Secrets configured ($SECRETS_SET set)${NC}"

# ── Verify deployment ──────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 5/5: Verifying Deployment${NC}"

echo "  Waiting for app to be ready..."
sleep 10

APP_URL="https://${APP_NAME}.fly.dev"
HEALTH_URL="${APP_URL}/health"

for i in {1..12}; do
    if curl -sf "$HEALTH_URL" > /dev/null 2>&1; then
        echo -e "${GREEN} App is healthy!${NC}"
        break
    fi
    echo "  Attempt $i/12..."
    sleep 5
done

# ── Summary ────────────────────────────────────────────────────

echo ""
echo "═══════════════════════════════════════════════════════════"
echo -e "  ${GREEN}${BOLD}Claude Mythos deployed successfully!${NC}"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo -e "  ${BOLD}App URL:${NC}     ${CYAN}${APP_URL}${NC}"
echo -e "  ${BOLD}Health:${NC}      ${CYAN}${HEALTH_URL}${NC}"
echo -e "  ${BOLD}Dashboard:${NC}   ${CYAN}${APP_URL}${NC}"
echo -e "  ${BOLD}API Docs:${NC}    ${CYAN}${APP_URL}/docs${NC}"
echo ""
echo -e "  ${BOLD}Commands:${NC}"
echo "    fly logs              - View live logs"
echo "    fly status            - Check app status"
echo "    fly ssh console       - Access container shell"
echo "    fly secrets list      - View configured secrets"
echo ""
echo -e "  ${BOLD}Costs:${NC} ~$5/month (1GB RAM, shared CPU, auto-stop)"
echo ""
echo -e "  ${YELLOW}Next: Configure your WhatsApp webhook:${NC}"
echo "    Webhook URL: ${APP_URL}/webhook/whatsapp"
echo ""
