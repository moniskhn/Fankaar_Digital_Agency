#!/bin/bash
# Claude Mythos - Universal VPS Setup Script
# Works on any Ubuntu/Debian VPS (DigitalOcean, Linode, Vultr, Hetzner, etc.)

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

APP_DIR="${APP_DIR:-/opt/claude-mythos}"
DOMAIN="${DOMAIN:-}"
APP_NAME="claude-mythos"

echo ""
echo -e "${BOLD}  Claude Mythos - Universal VPS Setup${NC}"
echo -e "  ${CYAN}Docker + Caddy + SSL + Firewall + Monitoring${NC}"
echo ""

# ── Check root ─────────────────────────────────────────────────

if [ "$EUID" -ne 0 ]; then
    echo -e "${RED} Please run as root or with sudo${NC}"
    exit 1
fi

# ── Detect OS ──────────────────────────────────────────────────

if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$NAME
else
    echo -e "${RED} Cannot detect OS${NC}"
    exit 1
fi

if [[ ! "$OS" =~ (Ubuntu|Debian) ]]; then
    echo -e "${YELLOW} This script is designed for Ubuntu/Debian${NC}"
    echo -e "${YELLOW} Detected: $OS${NC}"
    read -p "Continue anyway? [y/N] " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

echo -e "  OS: ${GREEN}${OS}${NC}"

# ── System update ──────────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 1/9: System Update${NC}"
apt-get update && apt-get upgrade -y

# ── Install Docker ─────────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 2/9: Installing Docker${NC}"

if command -v docker &> /dev/null; then
    echo -e "  ${GREEN}Docker already installed (${CYAN}$(docker --version)${GREEN})${NC}"
else
    echo "  Installing Docker..."
    curl -fsSL https://get.docker.com | sh
    usermod -aG docker root
    systemctl enable docker
    systemctl start docker
    echo -e "  ${GREEN}Docker installed${NC}"
fi

if command -v docker-compose &> /dev/null || docker compose version &> /dev/null; then
    echo -e "  ${GREEN}Docker Compose already installed${NC}"
else
    echo "  Installing Docker Compose..."
    COMPOSE_VERSION=$(curl -s https://api.github.com/repos/docker/compose/releases/latest | grep '"tag_name"' | cut -d'"' -f4)
    curl -L "https://github.com/docker/compose/releases/download/${COMPOSE_VERSION}/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose
    echo -e "  ${GREEN}Docker Compose installed${NC}"
fi

# ── Install Caddy ──────────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 3/9: Installing Caddy${NC}"

if command -v caddy &> /dev/null; then
    echo -e "  ${GREEN}Caddy already installed${NC}"
else
    echo "  Installing Caddy..."
    apt-get install -y debian-keyring debian-archive-keyring apt-transport-https
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list
    apt-get update && apt-get install -y caddy
    echo -e "  ${GREEN}Caddy installed${NC}"
fi

# ── Install utilities ──────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 4/9: Installing Utilities${NC}"

apt-get install -y -q \
    curl \
    wget \
    jq \
    git \
    ufw \
    fail2ban \
    logrotate \
    cron \
    htop \
    ncdu \
    certbot \
    python3-certbot-dns-cloudflare \
    2>/dev/null || apt-get install -y -q curl wget jq git ufw fail2ban logrotate cron htop

echo -e "  ${GREEN}Utilities installed${NC}"

# ── Setup firewall ─────────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 5/9: Configuring Firewall${NC}"

ufw --force reset
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp comment 'SSH'
ufw allow 80/tcp comment 'HTTP'
ufw allow 443/tcp comment 'HTTPS'

# Docker may open additional ports, restrict if needed
ufw --force enable

echo -e "  ${GREEN}Firewall configured${NC}"
ufw status verbose

# ── Setup fail2ban ─────────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 6/9: Configuring Fail2ban${NC}"

cat > /etc/fail2ban/jail.local << 'JAIL'
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5
backend = systemd

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3

[nginx-http-auth]
enabled = true
filter = nginx-http-auth
port = http,https
logpath = /var/log/nginx/error.log

[nginx-botsearch]
enabled = true
port = http,https
filter = nginx-botsearch
logpath = /var/log/nginx/access.log
maxretry = 2
JAIL

systemctl enable fail2ban
systemctl restart fail2ban

echo -e "  ${GREEN}Fail2ban configured${NC}"

# ── Create application directory ───────────────────────────────

echo ""
echo -e "${BOLD} Step 7/9: Setting up Application${NC}"

mkdir -p "$APP_DIR"
mkdir -p /var/log/caddy
mkdir -p /var/log/claude-mythos
mkdir -p /opt/backups

# Create docker-compose override
cat > "$APP_DIR/docker-compose.override.yml" << 'COMPOSE'
version: "3.8"
services:
  backend:
    build:
      context: .
      dockerfile: Dockerfile.backend
    container_name: mythos-backend
    restart: unless-stopped
    environment:
      - APP_ENV=production
      - DATABASE_PATH=/app/data/mythos.db
      - API_HOST=0.0.0.0
      - API_PORT=8000
      - WORKERS=2
      - CORS_ORIGINS=*
    volumes:
      - mythos-data:/app/data
    networks:
      - mythos-network
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "5"

  frontend:
    image: nginx:1.25-alpine
    container_name: mythos-frontend
    restart: unless-stopped
    volumes:
      - ./frontend/dist:/usr/share/nginx/html:ro
      - ./nginx.prod.conf:/etc/nginx/conf.d/default.conf:ro
    networks:
      - mythos-network
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

volumes:
  mythos-data:

networks:
  mythos-network:
    driver: bridge
COMPOSE

# Create systemd service for the app
cat > /etc/systemd/system/claude-mythos.service << SERVICE
[Unit]
Description=Claude Mythos AI Agency
After=docker.service
Requires=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=${APP_DIR}
ExecStartPre=-/usr/bin/docker-compose -f docker-compose.override.yml down
ExecStart=/usr/bin/docker-compose -f docker-compose.override.yml up -d
ExecStop=/usr/bin/docker-compose -f docker-compose.override.yml down
ExecReload=/usr/bin/docker-compose -f docker-compose.override.yml restart
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
SERVICE

# Create Caddyfile
CADDY_DOMAIN=":80"
if [ -n "$DOMAIN" ]; then
    CADDY_DOMAIN="$DOMAIN"
fi

cat > "$APP_DIR/Caddyfile" << CADDY
${CADDY_DOMAIN} {
    root * ${APP_DIR}/frontend/dist
    file_server {
        precompressed gzip zstd
    }
    try_files {path} {path}/ /index.html

    handle_path /api/* {
        reverse_proxy localhost:8000
    }

    handle_path /webhook/* {
        reverse_proxy localhost:8000
    }

    handle_path /docs {
        reverse_proxy localhost:8000
    }

    handle_path /health {
        reverse_proxy localhost:8000
    }

    encode gzip zstd

    header {
        Strict-Transport-Security "max-age=31536000; includeSubDomains"
        X-Frame-Options "SAMEORIGIN"
        X-Content-Type-Options "nosniff"
        X-XSS-Protection "1; mode=block"
        Referrer-Policy "strict-origin-when-cross-origin"
    }

    log {
        output file /var/log/caddy/mythos-access.log {
            roll_size 10MB
            roll_keep 5
            roll_keep_for 168h
        }
        format json
    }
}
CADDY

# Create systemd service for Caddy
cat > /etc/systemd/system/caddy-mythos.service << 'SERVICE'
[Unit]
Description=Caddy Reverse Proxy for Claude Mythos
After=network.target claude-mythos.service
Wants=claude-mythos.service

[Service]
Type=notify
ExecStart=/usr/bin/caddy run --config /opt/claude-mythos/Caddyfile
ExecReload=/usr/bin/caddy reload --config /opt/claude-mythos/Caddyfile
TimeoutStopSec=5s
LimitNOFILE=1048576
LimitNPROC=512
PrivateTmp=true
ProtectSystem=full
AmbientCapabilities=CAP_NET_BIND_SERVICE

[Install]
WantedBy=multi-user.target
SERVICE

# Create backup script
cat > /opt/backups/backup-mythos.sh << 'BACKUP'
#!/bin/bash
# Backup Claude Mythos SQLite database

BACKUP_DIR="/opt/backups"
DATE=$(date +%Y%m%d_%H%M%S)
DB_PATH="/var/lib/docker/volumes/mythos-data/_data/mythos.db"
BACKUP_FILE="${BACKUP_DIR}/mythos_${DATE}.db.gz"
RETENTION_DAYS=30

# Create backup
if [ -f "$DB_PATH" ]; then
    mkdir -p "$BACKUP_DIR"
    gzip -c "$DB_PATH" > "$BACKUP_FILE"
    echo "Backup created: $BACKUP_FILE"
    
    # Upload to S3 if configured
    if [ -n "${S3_BUCKET:-}" ]; then
        aws s3 cp "$BACKUP_FILE" "s3://${S3_BUCKET}/backups/" 2>/dev/null && echo "Uploaded to S3"
    fi
    
    # Clean old backups
    find "$BACKUP_DIR" -name "mythos_*.db.gz" -mtime +$RETENTION_DAYS -delete
    echo "Old backups cleaned (>${RETENTION_DAYS} days)"
else
    echo "Database not found at $DB_PATH"
    # Try alternative path
    docker exec mythos-backend cat /app/data/mythos.db 2>/dev/null | gzip > "$BACKUP_FILE" && echo "Backup created from container: $BACKUP_FILE"
fi
BACKUP
chmod +x /opt/backups/backup-mythos.sh

# Create cron job for daily backup
echo "0 3 * * * root /opt/backups/backup-mythos.sh >> /var/log/claude-mythos/backup.log 2>&1" > /etc/cron.d/claude-mythos-backup
chmod 644 /etc/cron.d/claude-mythos-backup

# Create logrotate config
cat > /etc/logrotate.d/claude-mythos << 'LOGROTATE'
/var/log/claude-mythos/*.log /var/log/caddy/*.log {
    daily
    rotate 14
    compress
    delaycompress
    missingok
    notifempty
    create 0640 root root
    sharedscripts
    postrotate
        /bin/kill -HUP $(cat /var/run/rsyslogd.pid 2> /dev/null) 2> /dev/null || true
    endscript
}
LOGROTATE

# Create nginx config
cat > "$APP_DIR/nginx.prod.conf" << 'NGINX'
server {
    listen 80;
    server_name _;
    root /usr/share/nginx/html;
    index index.html;

    gzip on;
    gzip_vary on;
    gzip_comp_level 6;
    gzip_types text/plain text/css application/json application/javascript text/xml;

    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;

    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://backend:8000/api/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_connect_timeout 30s;
        proxy_send_timeout 120s;
        proxy_read_timeout 120s;
    }

    location /webhook/ {
        proxy_pass http://backend:8000/webhook/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /health {
        proxy_pass http://backend:8000/health;
    }
}
NGINX

# Enable services
systemctl daemon-reload
systemctl enable claude-mythos
systemctl enable caddy-mythos

echo -e "  ${GREEN}Application configured in ${CYAN}${APP_DIR}${NC}"

# ── SSL certificate ────────────────────────────────────────────

echo ""
echo -e "${BOLD} Step 8/9: SSL Certificate${NC}"

if [ -n "$DOMAIN" ] && [ "$DOMAIN" != ":80" ]; then
    echo "  Domain configured: $DOMAIN"
    echo "  ${YELLOW}Note: Caddy will automatically obtain SSL on first start${NC}"
    echo "  ${YELLOW}Ensure DNS A record points to this server's IP${NC}"
else
    echo -e "  ${YELLOW}No domain configured. Using HTTP only.${NC}"
    echo "  To add SSL later, set DOMAIN and run: certbot --nginx"
fi

# ── Summary ────────────────────────────────────────────────────

echo ""
echo "═══════════════════════════════════════════════════════════"
echo -e "  ${GREEN}${BOLD}VPS Setup Complete!${NC}"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo -e "  ${BOLD}Services:${NC}"
echo "    systemctl start claude-mythos     - Start the app"
echo "    systemctl stop claude-mythos      - Stop the app"
echo "    systemctl restart claude-mythos   - Restart the app"
echo "    systemctl status caddy-mythos     - Check Caddy proxy"
echo ""
echo -e "  ${BOLD}Logs:${NC}"
echo "    journalctl -u claude-mythos -f    - App logs"
echo "    journalctl -u caddy-mythos -f     - Caddy logs"
echo "    /var/log/caddy/mythos-access.log  - Access logs"
echo "    /var/log/claude-mythos/           - Backup logs"
echo ""
echo -e "  ${BOLD}Database:${NC}"
echo "    /opt/backups/backup-mythos.sh     - Manual backup"
echo "    /opt/backups/                     - Backup directory"
echo "    Daily backups at 3 AM (cron)"
echo ""
echo -e "  ${BOLD}Security:${NC}"
echo "    UFW firewall: active (ports 22, 80, 443)"
echo "    Fail2ban: active (SSH brute-force protection)"
echo "    Auto-updates: apt unattended-upgrades recommended"
echo ""
echo -e "  ${BOLD}Next Steps:${NC}"
echo "  1. Copy your application code to ${APP_DIR}/"
echo "  2. Build frontend: cd frontend && npm install && npm run build"
echo "  3. Copy dist to ${APP_DIR}/frontend/dist/"
echo "  4. Create ${APP_DIR}/.env with your secrets"
echo "  5. Start: systemctl start claude-mythos caddy-mythos"
echo "  6. Check health: curl http://localhost:8000/health"
echo ""
