# Claude Mythos — Complete Launch Playbook
## From Zero to Your First Paying Client

---

## PHASE 1: Download & Setup (15 minutes)

### Step 1: Get the Project

```bash
# Create a folder for your agency
mkdir -p ~/claude-mythos && cd ~/claude-mythos

# Download the project (use the zip file provided)
# Extract it:
unzip claude-mythos-agency.zip -d .
# Or if you have the file elsewhere:
# cp /path/to/claude-mythos-agency.zip . && unzip claude-mythos-agency.zip

# You should now have:
# ~/claude-mythos/project/backend/
# ~/claude-mythos/project/landing/
# ~/claude-mythos/project/docker-compose.yml
# etc.
```

### Step 2: Install Prerequisites

**MacBook Requirements:**
- macOS 12+ (Monterey or newer)
- 8GB RAM minimum (16GB recommended)
- ~2GB free disk space

**Install these tools:**

```bash
# 1. Docker Desktop (if not installed)
brew install --cask docker
# Then open Docker Desktop app once to complete setup

# 2. Python 3.11+ (if not installed)
brew install python@3.11

# 3. Git (if not installed)
brew install git

# 4. Fly CLI (for cloud deploy - easiest option)
brew install flyctl

# Verify installations:
docker --version      # Should show 24.x+
python3 --version     # Should show 3.11+
fly version           # Should show version number
```

### Step 3: Create Your Environment File

```bash
cd ~/claude-mythos/project/backend
cp .env.example .env
open -e .env  # Opens in TextEdit, or use nano/vim
```

**Fill in these REQUIRED values:**

```env
# ===== LLM (AI Brain) - PICK ONE =====

# Option A: Anthropic Claude (RECOMMENDED - best quality)
LLM_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-api03-your-key-here

# Option B: OpenAI
# LLM_PROVIDER=openai
# OPENAI_API_KEY=sk-your-key-here

# Option C: Local (free but needs more setup)
# LLM_PROVIDER=ollama
# OLLAMA_HOST=host.docker.internal:11434
# OLLAMA_MODEL=llama3.2

# ===== WhatsApp (CEO Daily Reports) =====
TWILIO_ACCOUNT_SID=AC-your-account-sid-here
TWILIO_AUTH_TOKEN=your-auth-token-here
TWILIO_WHATSAPP_NUMBER=+14155238886
OWNER_WHATSAPP_NUMBER=+your-actual-phone-number

# ===== Stripe (Payments) =====
STRIPE_SECRET_KEY=sk_test_your-key-here
STRIPE_PUBLISHABLE_KEY=pk_test_your-key-here
STRIPE_WEBHOOK_SECRET=whsec_your-webhook-secret

# Stripe Price IDs (create these in Stripe Dashboard first)
STRIPE_STARTER_PRICE_ID=price_your-starter-price-id
STRIPE_GROWTH_PRICE_ID=price_your-growth-price-id
STRIPE_ENTERPRISE_PRICE_ID=price_your-enterprise-price-id

# ===== Agency Settings =====
AGENCY_NAME=Claude Mythos
OWNER_NAME=Boss
DAILY_REPORT_TIME=09:00
DAILY_REPORT_TIMEZONE=Asia/Dubai

# ===== Database =====
DATABASE_PATH=/app/data/mythos.db
```

---

## PHASE 2: Get Your API Keys (20-30 minutes)

### Step 4: Anthropic API Key (AI Brain)

```
1. Go to https://console.anthropic.com/
2. Sign up (Google account or email)
3. Go to "Get API keys" → "Create Key"
4. Name it "Claude Mythos Agency"
5. Copy the key (starts with sk-ant-)
6. Paste into .env file: ANTHROPIC_API_KEY=sk-ant-...
```

**Expected cost:** $0.50-2/day per active client. Start with $20 credit.

### Step 5: Twilio (WhatsApp Messages from Your CEO)

```
1. Go to https://www.twilio.com/try-twilio
2. Sign up (free trial with $15.50 credit)
3. Verify your phone number
4. Get your Account SID (starts with AC...)
5. Get your Auth Token (click "Show")
6. Go to Messaging → Try it out → Send a WhatsApp message
7. Join the sandbox by messaging the number they give you
8. Copy the sandbox WhatsApp number (e.g., +14155238886)
9. Paste into .env:
   TWILIO_ACCOUNT_SID=AC...
   TWILIO_AUTH_TOKEN=...
   TWILIO_WHATSAPP_NUMBER=+14155238886
   OWNER_WHATSAPP_NUMBER=+971YOURNUMBER (your real number with country code)
```

**Expected cost:** ~$0.005 per message. Daily reports = ~$0.15/month.

### Step 6: Stripe (Accept Payments)

```
1. Go to https://dashboard.stripe.com/register
2. Sign up (free, pay only when you earn)
3. Go to Developers → API keys
4. Copy Publishable key (pk_test_...)
5. Copy Secret key (sk_test_...) — click "Reveal test key"
6. Create your products:
   
   a. Products → Add product
   b. Name: "Starter Plan"
   c. Price: $499/month → Recurring
   d. Save → copy Price ID (price_...)
   
   e. Repeat for "Growth Plan" ($1,499/mo)
   f. Repeat for "Enterprise Plan" ($3,999/mo)

7. Go to Developers → Webhooks → Add endpoint
   - Endpoint URL: https://your-domain.com/webhook/stripe
   - (For local testing, use Stripe CLI or skip for now)
   - Select events: checkout.session.completed, invoice.paid, invoice.payment_failed, customer.subscription.deleted
   - Copy signing secret (whsec_...)

8. Paste into .env:
   STRIPE_SECRET_KEY=sk_test_...
   STRIPE_PUBLISHABLE_KEY=pk_test_...
   STRIPE_WEBHOOK_SECRET=whsec_...
   STRIPE_STARTER_PRICE_ID=price_...
   STRIPE_GROWTH_PRICE_ID=price_...
   STRIPE_ENTERPRISE_PRICE_ID=price_...
```

**Expected cost:** Stripe takes 2.9% + $0.30 per transaction. On $1,499 = ~$43 fee. You keep $1,456.

---

## PHASE 3: Launch Locally (10 minutes)

### Step 7: Start Your Agency on MacBook

```bash
cd ~/claude-mythos/project

# Start everything with Docker
./start.sh
```

You should see:
```
🏰 Claude Mythos — Launching Your AI Agency...
[1/5] Checking Docker... ✅
[2/5] Checking configuration... ✅
[3/5] Building services... ✅
[4/5] Starting services... ✅
[5/5] Checking health... ✅

═══════════════════════════════════════════
  🏰 Claude Mythos is ONLINE
═══════════════════════════════════════════

Dashboard:  http://localhost:3000
API:        http://localhost:8000
Health:     http://localhost:8000/health

Your 23 AI employees are ready for duty.
```

### Step 8: Verify Everything Works

```bash
# Check backend is running
curl http://localhost:8000/health
# Should return: {"status":"healthy","version":"1.0.0"}

# Check all 23 agents are registered
curl http://localhost:8000/api/agents | python3 -m json.tool | grep name

# Open dashboard in browser
open http://localhost:3000
```

**You should see:** The Agency HQ dashboard with all 23 agents, stats, activity feed.

### Step 9: Test CEO WhatsApp Report

```bash
# Trigger a test daily report
curl -X POST http://localhost:8000/api/ceo/daily-report/send
```

Check your WhatsApp — you should receive a message from Jon Snow within 30 seconds.

---

## PHASE 4: Go Live on the Internet (10 minutes)

### Option A: Fly.io (RECOMMENDED - Easiest)

```bash
# 1. Make sure you're logged in
fly auth login

# 2. Launch (from project directory)
cd ~/claude-mythos/project
fly launch --name claude-mythos --region dub

# 3. Set your secrets (one at a time)
fly secrets set ANTHROPIC_API_KEY=sk-ant-your-actual-key
fly secrets set TWILIO_ACCOUNT_SID=AC-your-actual-sid
fly secrets set TWILIO_AUTH_TOKEN=your-actual-token
fly secrets set TWILIO_WHATSAPP_NUMBER=+14155238886
fly secrets set OWNER_WHATSAPP_NUMBER=+your-actual-number
fly secrets set STRIPE_SECRET_KEY=sk_test_your-actual-key
fly secrets set STRIPE_PUBLISHABLE_KEY=pk_test_your-actual-key
fly secrets set STRIPE_WEBHOOK_SECRET=whsec_your-actual-secret
fly secrets set STRIPE_STARTER_PRICE_ID=price_your-actual-id
fly secrets set STRIPE_GROWTH_PRICE_ID=price_your-actual-id
fly secrets set STRIPE_ENTERPRISE_PRICE_ID=price_your-actual-id

# 4. Deploy
fly deploy

# 5. Open your live agency
fly open
# → Opens https://claude-mythos.fly.dev (your live URL)
```

**Cost:** ~$5/month

### Option B: Railway (Also Easy)

```bash
# 1. Install Railway CLI
npm install -g @railway/cli

# 2. Login
railway login

# 3. Initialize and deploy
cd ~/claude-mythos/project
railway init
railway up

# 4. Set environment variables in Railway dashboard
# Go to https://railway.app/project/[your-project]/variables
# Add all the same env vars as above

# 5. Your URL will be: https://claude-mythos.up.railway.app
```

### Option C: Render (Free Tier)

```bash
# 1. Push to GitHub first
git init
git add .
git commit -m "Initial agency launch"
# Create GitHub repo and push

# 2. Go to https://render.com/
# 3. Click "New Web Service"
# 4. Connect your GitHub repo
# 5. Set build command: cd backend && pip install -r requirements.txt
# 6. Set start command: cd backend && uvicorn app.main:app --host 0.0.0.0 --port 8000
# 7. Add environment variables in Render dashboard
# 8. Deploy
```

---

## PHASE 5: Configure Your Public Landing Page (10 minutes)

### Step 10: Update Landing Page With Your Info

```bash
# Open the landing page
open ~/claude-mythos/project/landing/index.html

# Or edit with any text editor:
open -e ~/claude-mythos/project/landing/index.html
```

**Search and replace these placeholders:**

```html
<!-- Find and update: -->

<!-- 1. Your agency name (if different) -->
<!-- Already "Claude Mythos" - keep or change -->

<!-- 2. Your contact info -->
<!-- Find: contact@claudemythos.com -->
<!-- Replace with: your-email@yourdomain.com -->

<!-- 3. Your WhatsApp number -->
<!-- Find: +1 (555) 000-0000 -->
<!-- Replace with: your actual WhatsApp business number -->

<!-- 4. Your domain (after deploy) -->
<!-- Find: #signup links -->
<!-- Replace with: your actual signup/onboarding URL -->
```

### Step 11: Deploy Landing Page

**Option A: Same as backend (Fly.io)**
```bash
# The landing page is served as static files
# Upload landing/ folder to any static host:

# Using Fly.io:
fly deploy --dockerfile Dockerfile.frontend

# Or simply use the built-in static serving:
# The backend already serves frontend from /frontend/dist/
# Copy landing/index.html to that folder:
cp ~/claude-mythos/project/landing/index.html ~/claude-mythos/project/frontend/dist/
# Then redeploy: fly deploy
```

**Option B: Free static hosting**
```bash
# Netlify (free)
npm install -g netlify-cli
netlify deploy --dir=~/claude-mythos/project/landing --prod
# → Gives you: https://claude-mythos-agency.netlify.app

# Vercel (free)
npm install -g vercel
vercel --yes ~/claude-mythos/project/landing
# → Gives you: https://claude-mythos-agency.vercel.app

# Cloudflare Pages (free)
# Go to https://pages.cloudflare.com/ → upload folder
```

---

## PHASE 6: Get Your First Client (Ongoing)

### Step 12: Test the Full Client Flow

**Pretend you're a client and test everything:**

```
1. Visit your landing page
2. Click "Start Growth Plan"
3. Complete the 5-step onboarding:
   - Step 1: Enter a fake company name, your industry
   - Step 2: Pick marketing goals
   - Step 3: Select your region (Dubai, London, NYC, etc.)
   - Step 4: Describe your brand voice
   - Step 5: Pick package and pay (use Stripe test card: 4242 4242 4242 4242)
4. Check your dashboard — new client should appear
5. Watch agents get assigned tasks automatically
6. Check WhatsApp — Jon should report the new client
```

### Step 13: Find Real Clients

**Where to find your first 3 clients:**

| Channel | Action | Expected Result |
|---------|--------|----------------|
| **LinkedIn** | Post daily about AI marketing. Comment on posts by business owners. | 1-2 leads/week |
| **Reddit** | Post in r/marketing, r/smallbusiness, r/entrepreneur. Offer free audits. | 2-3 leads/week |
| **Twitter/X** | Share before/after results. Thread about AI in marketing. | 1-2 leads/week |
| **Local businesses** | Walk into 10 local businesses with a printed one-pager. | 1-3 clients |
| **Your network** | Text 20 people you know: "I started an AI marketing agency. Need help?" | 2-5 warm leads |
| **Freelance platforms** | List on Upwork, Fiverr as "AI Marketing Agency" | Ongoing leads |

**Your pitch (simple):**
> "I run an AI marketing agency with 23 specialists — strategists, copywriters, SEO experts, ad managers, designers — all powered by AI. We deliver in 48 hours what takes traditional agencies 2 weeks. Plans start at $499/month. Want a free marketing audit?"

### Step 14: Deliver Your First Campaign

```
1. Client completes onboarding →系统自动 creates campaign brief
2. Bran (Strategy) auto-generates a strategic plan within 2 minutes
3. Tyrion (Writer) creates all copy within 5 minutes
4. Missandei (Social) builds the content calendar
5. You review via dashboard → approve or request changes
6. Jon (CEO) sends you a WhatsApp summary
7. You present to client → collect feedback
8. Agents iterate based on feedback (auto-learns preferences)
9. Launch campaign → Bronn (Ads) + Missandei (Social) execute
10. Samwell (Analytics) generates performance reports
```

---

## PHASE 7: Scale (Month 2+)

### Step 15: Automate Everything

```bash
# Your daily routine (5 minutes):
# 1. Check WhatsApp for Jon's morning report
# 2. Reply "approve" or "reject" to any decisions
# 3. Quick dashboard check for any flagged items
# 4. Done — agents handle the rest

# Weekly (30 minutes):
# 1. Review all active campaigns
# 2. Check Stripe revenue
# 3. Reply to any client messages forwarded by Davos
# 4. Plan next week's outreach

# Monthly (2 hours):
# 1. Review analytics and ROI per client
# 2. Adjust service packages if needed
# 3. Content creation for your own marketing
# 4. Client retention check-ins
```

### Step 16: Scale to 10+ Clients

| Clients | Revenue/Month | Your Work/Week | API Cost/Month |
|---------|--------------|----------------|----------------|
| 1 Starter | $499 | ~2 hours | ~$15 |
| 3 Growth | $4,497 | ~3 hours | ~$90 |
| 5 Growth | $7,495 | ~4 hours | ~$150 |
| 10 Growth | $14,990 | ~5 hours | ~$300 |
| 5 Enterprise | $19,995 | ~8 hours | ~$500 |

**At 10 Growth clients:** $14,990/mo revenue - $300 API - $5 hosting = **$14,685 profit**

---

## TROUBLESHOOTING

### Docker won't start
```bash
# Make sure Docker Desktop is running
open -a Docker

# Check Docker
docker ps
# If empty, wait 30 seconds and try again

# Rebuild
cd ~/claude-mythos/project
docker-compose down
docker-compose build --no-cache
docker-compose up -d
```

### Backend won't start
```bash
# Check logs
docker-compose logs backend

# Common fix: database permissions
docker-compose exec backend bash
chmod 777 /app/data/
exit
docker-compose restart backend
```

### WhatsApp not working
```bash
# Test Twilio credentials
curl -X POST https://api.twilio.com/2010-04-01/Accounts/YOUR_SID/Messages.json \
  --data-urlencode "From=whatsapp:+14155238886" \
  --data-urlencode "To=whatsapp:+YOURNUMBER" \
  --data-urlencode "Body=Test message" \
  -u "YOUR_SID:YOUR_AUTH_TOKEN"

# If that works, check your .env is correct
docker-compose exec backend cat .env
```

### Agents not doing work
```bash
# Check runtime status
curl http://localhost:8000/api/runtime/status

# Start runtime manually
curl -X POST http://localhost:8000/api/runtime/start

# Force execute a task
curl -X POST http://localhost:8000/api/runtime/execute/{task_id}
```

### Landing page not loading
```bash
# Test locally
open ~/claude-mythos/project/landing/index.html

# If it opens in browser fine, it's a hosting issue
# Re-upload to your static host
```

---

## COST SUMMARY (First Month)

| Item | Cost |
|------|------|
| Anthropic API (testing + 1 client) | ~$30 |
| Twilio WhatsApp | ~$1 |
| Fly.io hosting | $5 |
| Domain name (optional) | $10-15/year |
| **Total first month** | **~$36** |
| **At 1 Growth client** | **$1,499 revenue - $36 cost = $1,463 profit** |

---

## QUICK REFERENCE: Key Commands

```bash
# LOCAL DEVELOPMENT
cd ~/claude-mythos/project
./start.sh          # Start everything
./stop.sh           # Stop everything
docker-compose logs -f backend   # Watch logs

# DEPLOYMENT (Fly.io)
fly deploy          # Deploy latest code
fly logs            # View live logs
fly secrets list    # View configured secrets
fly status          # Check app status
fly open            # Open live URL

# API TESTS
curl http://localhost:8000/api/agents                    # List agents
curl http://localhost:8000/api/dashboard/stats           # Dashboard stats
curl http://localhost:8000/api/ceo/daily-report          # Generate report
curl -X POST http://localhost:8000/api/ceo/daily-report/send   # Send WhatsApp
curl http://localhost:8000/api/runtime/status            # Runtime status

# DATABASE
docker-compose exec backend sqlite3 /app/data/mythos.db ".tables"

# BACKUP
cp ~/claude-mythos/project/data/mythos.db ~/mythos-backup-$(date +%Y%m%d).db
```

---

## YOUR 30-DAY TIMELINE

| Day | Action | Goal |
|-----|--------|------|
| **1** | Download, setup, get API keys | Agency running locally |
| **2** | Deploy to Fly.io | Agency live on internet |
| **3** | Set up landing page, Stripe | Ready to accept clients |
| **4-7** | Test full flow, fix any issues | Everything works smoothly |
| **8-14** | Reach out to 50+ people | 5-10 warm conversations |
| **15-21** | Do 3 free audits | Build case studies |
| **22-28** | Convert audits to paid | **First 1-3 paying clients** |
| **29-30** | Optimize, document, plan | Ready to scale |

---

**You now have everything you need. Your 23 AI employees are waiting. Go launch your agency.**

*"When you play the game of marketing, you win or you learn."* — Jon Snow, CEO
