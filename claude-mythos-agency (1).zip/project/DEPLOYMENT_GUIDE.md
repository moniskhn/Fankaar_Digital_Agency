# Claude Mythos - Deployment Guide

Complete deployment guide for the Claude Mythos AI Digital Marketing Agency platform. Deploy your 23 AI employees to the cloud in minutes.

---

## Quick Start (5 minutes) - Fly.io **(RECOMMENDED)**

Fly.io is the simplest, most affordable platform for Claude Mythos. Auto-stop saves money when not in use.

```bash
# 1. Install flyctl
curl -L https://fly.io/install.sh | sh

# 2. Login
fly auth login

# 3. Clone and enter the project
git clone <your-repo> && cd claude-mythos

# 4. Deploy (one command!)
./scripts/deploy-fly.sh

# 5. Set your API keys
fly secrets set ANTHROPIC_API_KEY=sk-ant-xxx
fly secrets set TWILIO_ACCOUNT_SID=ACxxx
fly secrets set TWILIO_AUTH_TOKEN=xxx
fly secrets set OWNER_WHATSAPP_NUMBER=+971xxx

# 6. Open your app
fly open
```

That's it! Your AI agency is live at `https://claude-mythos.fly.dev`.

---

## Platform Comparison

| Platform | Cost | Difficulty | Best For |
|----------|------|------------|----------|
| **Local MacBook** | Free | Easy | Development, testing |
| **[Fly.io](#flyio)** | ~$5/mo | Very Easy | **Recommended** - production, global CDN |
| **[Railway](#railway)** | ~$5/mo | Very Easy | Quick deploy, auto-scaling |
| **[Render](#render)** | Free tier | Easy | Testing, low traffic |
| **[DigitalOcean](#digitalocean)** | $6/mo | Medium | Full control, cheapest VPS |
| **[AWS ECS](#aws)** | $30-50/mo | Hard | Enterprise, massive scale |
| **[Home Server/VPS](#vps)](#vps)** | Free (electricity) | Medium | Privacy, no cloud dependency |

---

## Fly.io (Recommended)

**Why Fly.io?** Global edge deployment, auto-SSL, auto-stop (saves money), persistent volumes, simplest setup.

### Option A: Automated Deploy Script

```bash
./scripts/deploy-fly.sh
```

This interactive script handles everything: CLI check, auth, volume creation, deployment, secret configuration.

### Option B: Manual Steps

```bash
# Install flyctl
curl -L https://fly.io/install.sh | sh

# Launch app (creates fly.toml)
fly launch --name claude-mythos --region ams

# Create persistent volume for SQLite
fly volumes create mythos_data --region ams --size 3

# Set required secrets
fly secrets set ANTHROPIC_API_KEY=sk-ant-xxx
fly secrets set TWILIO_ACCOUNT_SID=ACxxx
fly secrets set TWILIO_AUTH_TOKEN=xxx
fly secrets set TWILIO_WHATSAPP_NUMBER=+1415xxx
fly secrets set OWNER_WHATSAPP_NUMBER=+971xxx

# Deploy
fly deploy

# Check status
fly status
fly logs
```

### Fly.io Configuration

The `fly.toml` includes:
- **Auto-stop**: Machine stops when idle (saves ~70% cost)
- **Auto-start**: Machine starts on first request (~2s cold start)
- **Health checks**: `/health` endpoint monitoring
- **Persistent volume**: SQLite database survives restarts
- **1GB RAM + shared CPU**: Enough for LLM API calls

### Custom Domain on Fly.io

```bash
# Add your domain
fly certs add mythos.yourdomain.com

# Update DNS: Create CNAME record pointing to claude-mythos.fly.dev
# Fly handles SSL automatically
```

### Fly.io Commands

| Command | Description |
|---------|-------------|
| `fly deploy` | Deploy latest code |
| `fly logs` | View live logs |
| `fly status` | Check app status |
| `fly ssh console` | Shell access |
| `fly secrets list` | View secrets (names only) |
| `fly machine list` | View machines |
| `fly machine stop <id>` | Stop a machine |

---

## Railway

**Why Railway?** Zero-config deploys, automatic HTTPS, great DX.

### Deploy

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# Deploy with our script
./scripts/deploy-railway.sh
```

### Manual Deploy

```bash
# Link project
railway init --name claude-mythos

# Add persistent volume (REQUIRED for SQLite)
# Go to Railway Dashboard > Volumes > New Volume
# Mount path: /app/data, Size: 1GB

# Deploy
railway up

# Set environment variables
railway variables --set "ANTHROPIC_API_KEY=sk-ant-xxx"
```

### Railway Gotchas

- **Volumes are required** - SQLite data is lost on restart without a volume
- Volume must be mounted at `/app/data`
- Free tier includes $5/month credit

---

## Render

**Why Render?** Generous free tier, static sites are always free.

### Deploy via Blueprint

1. Push code to GitHub/GitLab
2. Go to [Render Dashboard](https://dashboard.render.com/blueprints)
3. Click "New Blueprint Instance"
4. Connect your repository
5. Render reads `render.yaml` and creates services automatically

### Manual Deploy

1. **Create Web Service**: New > Web Service
2. Connect repo, select Docker runtime
3. Set Dockerfile path: `Dockerfile.backend`
4. Add environment variables
5. Add disk: mount `/app/data`, size 1GB
6. Set health check path: `/health`

### Render Free Tier Limitations

- Web services sleep after 15 minutes of inactivity
- First request after sleep takes ~30 seconds
- Upgrade to Starter ($7/mo) for always-on

---

## DigitalOcean

**Why DigitalOcean?** Full control, cheapest VPS, simple pricing.

### Deploy

```bash
# Install doctl: https://docs.digitalocean.com/reference/doctl/how-to/install/
# Authenticate: doctl auth init

# Deploy with our script
./scripts/deploy-digitalocean.sh
```

### What the Script Does

1. Creates Ubuntu 24.04 droplet ($6/month)
2. Installs Docker + Docker Compose + Caddy
3. Configures UFW firewall (ports 22, 80, 443)
4. Sets up fail2ban for SSH protection
5. Creates systemd services for auto-start
6. Configures log rotation and daily backups

### After Deploy

```bash
# Copy your .env file
scp .env root@<DROPLET_IP>:/opt/claude-mythos/

# SSH into server
ssh root@<DROPLET_IP>

# Start services
systemctl start claude-mythos caddy-mythos

# Check status
systemctl status claude-mythos
docker logs mythos-backend
```

### Custom Domain

```bash
# Update your DNS: A record -> <DROPLET_IP>
# Then update Caddyfile:
cat > /opt/claude-mythos/Caddyfile << 'EOF'
mythos.yourdomain.com {
    root * /opt/claude-mythos/frontend/dist
    file_server
    try_files {path} /index.html
    reverse_proxy /api/* localhost:8000
    reverse_proxy /webhook/* localhost:8000
    encode gzip zstd
    tls {
        protocols tls1.2 tls1.3
    }
}
EOF

systemctl restart caddy-mythos
```

---

## AWS ECS (Enterprise)

**Why AWS?** Massive scale, enterprise security, full control.

### Prerequisites

- AWS CLI configured (`aws configure`)
- Terraform installed (`terraform init`)
- Domain name (optional, for HTTPS)

### Deploy

```bash
cd terraform

# Copy example variables
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your secrets

# Initialize
terraform init

# Plan
terraform plan

# Apply (takes ~10 minutes)
terraform apply

# Get outputs
terraform output app_url
terraform output webhook_url
```

### AWS Architecture

```
Internet --> ALB (HTTPS) --> ECS Fargate (container)
                                  |
                            EFS (SQLite persistence)
                                  |
                            CloudWatch (logs)
                                  |
                            SSM Parameter Store (secrets)
```

### AWS Costs

| Component | Cost/Month |
|-----------|-----------|
| ECS Fargate (1 task, 0.5 vCPU, 1GB) | ~$15 |
| Application Load Balancer | ~$16 |
| EFS (1GB) | ~$0.30 |
| Data transfer | ~$0-10 |
| **Total** | **~$30-50/month** |

### AWS Commands

```bash
# View logs
aws logs tail /ecs/claude-mythos-backend --follow

# Scale up
terraform apply -var="desired_count=2"

# View resources
aws ecs list-tasks --cluster claude-mythos-cluster
aws ecs describe-services --cluster claude-mythos-cluster --services claude-mythos-backend
```

---

## Universal VPS Setup

For any Ubuntu/Debian VPS (Linode, Vultr, Hetzner, OVH, etc.):

```bash
# Run the universal setup script (as root)
./scripts/setup-vps.sh

# Then:
# 1. Copy your code to /opt/claude-mythos/
# 2. Build frontend and copy dist to /opt/claude-mythos/frontend/dist/
# 3. Create .env file
# 4. Start: systemctl start claude-mythos caddy-mythos
```

### What Gets Installed

- Docker & Docker Compose
- Caddy (reverse proxy + auto-SSL)
- UFW firewall (ports 22, 80, 443)
- Fail2ban (brute-force protection)
- Log rotation
- Daily SQLite backups
- Systemd services (auto-start on boot)

---

## Environment Variables Reference

### Required

| Variable | Description | Example |
|----------|-------------|---------|
| `ANTHROPIC_API_KEY` | Claude API key | `sk-ant-api03-...` |
| `LLM_PROVIDER` | Which LLM to use | `anthropic` |

### WhatsApp (Optional but Recommended)

| Variable | Description | Example |
|----------|-------------|---------|
| `TWILIO_ACCOUNT_SID` | Twilio Account SID | `ACxxxxxxxx...` |
| `TWILIO_AUTH_TOKEN` | Twilio Auth Token | `xxxxxxxx...` |
| `TWILIO_WHATSAPP_NUMBER` | Twilio WhatsApp number | `+1415xxxxxxx` |
| `OWNER_WHATSAPP_NUMBER` | Your number for reports | `+971xxxxxxxxx` |

### Application Settings (Optional)

| Variable | Description | Default |
|----------|-------------|---------|
| `AGENCY_NAME` | Name of your AI agency | `Claude Mythos` |
| `OWNER_NAME` | Your name/title | `Boss` |
| `DAILY_REPORT_TIME` | When to send WhatsApp reports | `09:00` |
| `DAILY_REPORT_TIMEZONE` | Your timezone | `UTC` |
| `ANTHROPIC_MODEL` | Claude model | `claude-3-5-sonnet-20241022` |
| `LOG_LEVEL` | Logging level | `INFO` |
| `DATABASE_PATH` | SQLite file path | `/app/data/mythos.db` |
| `CORS_ORIGINS` | Allowed frontend origins | `*` (prod) |
| `WORKERS` | Gunicorn workers | `4` |

### How to Set by Platform

| Platform | Method |
|----------|--------|
| Fly.io | `fly secrets set KEY=value` |
| Railway | Dashboard > Variables or `railway variables --set KEY=value` |
| Render | Dashboard > Environment |
| DigitalOcean | SSH to droplet, edit `/opt/claude-mythos/.env` |
| AWS | SSM Parameter Store (set via Terraform) |
| VPS | Edit `.env` file in app directory |

---

## WhatsApp Setup Guide

### 1. Create Twilio Account

1. Go to [twilio.com](https://www.twilio.com) and sign up
2. Get a free trial phone number
3. Note your **Account SID** and **Auth Token** from the dashboard

### 2. Activate WhatsApp Sandbox

1. In Twilio Console, go to **Messaging > Try it out > Send a WhatsApp message**
2. You'll see a WhatsApp sandbox number (e.g., `+14155238886`)
3. Send the join message from your phone to that number
4. Your phone number is now registered

### 3. Configure Webhook

After deploying Claude Mythos, set the webhook URL in Twilio:

```
https://<YOUR_APP_URL>/webhook/whatsapp
```

Example:
```
https://claude-mythos.fly.dev/webhook/whatsapp
```

In Twilio Console:
1. Go to **Messaging > Settings > WhatsApp Sandbox Settings**
2. Set "When a message comes in" webhook URL
3. Set method to HTTP POST
4. Save

### 4. Set Environment Variables

```bash
# Fly.io example
fly secrets set TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
fly secrets set TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
fly secrets set TWILIO_WHATSAPP_NUMBER=+14155238886
fly secrets set OWNER_WHATSAPP_NUMBER=+971xxxxxxxxxx
```

### 5. Test

Send a WhatsApp message to the Twilio sandbox number. You should receive a response from your AI agency!

### 6. Go to Production

1. Apply for a [Twilio WhatsApp Business API](https://www.twilio.com/whatsapp)
2. Submit business profile for approval (1-3 days)
3. Once approved, use your approved number instead of the sandbox

---

## Domain Setup

### Fly.io

```bash
fly certs add mythos.yourdomain.com
# Then create CNAME: mythos.yourdomain.com -> claude-mythos.fly.dev
```

### Railway

Railway provides a default `.up.railway.app` domain. For custom domains:
1. Dashboard > Settings > Domains
2. Add custom domain
3. Update DNS CNAME record

### Render

Render provides `.onrender.com` subdomain. For custom domains:
1. Dashboard > Settings > Custom Domains
2. Add domain
3. Update DNS

### DigitalOcean / VPS

1. Buy domain from registrar (Namecheap, Cloudflare, etc.)
2. Create A record pointing to your server IP
3. Caddy automatically obtains SSL certificate on first start

### AWS

Set in Terraform:
```hcl
domain_name    = "mythos.yourdomain.com"
hosted_zone_id = "Z1234567890ABC"  # From Route 53
```

---

## Monitoring & Health Checks

### Health Check Endpoint

All deployments expose a health check at `/health`:

```json
{
  "status": "healthy",
  "version": "1.0.0",
  "llm_provider": "anthropic",
  "llm_available": true,
  "whatsapp_configured": true,
  "database_connected": true,
  "agent_count": 23,
  "environment": "production"
}
```

### Checking Agent Status

```bash
# Check all agents
curl https://your-app.com/api/agents

# Check CEO status
curl https://your-app.com/api/ceo/status

# Check dashboard stats
curl https://your-app.com/api/dashboard/stats
```

### Logs by Platform

| Platform | How to View Logs |
|----------|-----------------|
| Fly.io | `fly logs` or Dashboard |
| Railway | `railway logs` or Dashboard |
| Render | Dashboard > Logs |
| DigitalOcean | `docker logs mythos-backend` |
| AWS | `aws logs tail /ecs/claude-mythos-backend --follow` |
| VPS | `journalctl -u claude-mythos -f` |

### Monitoring Recommendations

1. **Uptime monitoring**: Use [UptimeRobot](https://uptimerobot.com) (free) to monitor `/health`
2. **Log alerts**: Set up CloudWatch (AWS) or Logtail (generic) for error notifications
3. **WhatsApp test**: Send a daily test message to verify the pipeline

---

## Updating Your Deployment

### Code Updates

```bash
# Pull latest code
git pull origin main

# Fly.io
fly deploy

# Railway (auto-deploys on git push)
git push origin main

# Render (auto-deploys on git push)
git push origin main

# DigitalOcean / VPS
# Pull code, rebuild, restart:
cd /opt/claude-mythos && git pull && docker-compose -f docker-compose.override.yml up -d --build

# AWS
# Build and push new image, ECS auto-deploys:
docker build -f Dockerfile.backend -t claude-mythos .
docker tag claude-mythos:latest $(terraform output -raw ecr_repository_url):latest
docker push $(terraform output -raw ecr_repository_url):latest
aws ecs update-service --cluster claude-mythos-cluster --service claude-mythos-backend --force-new-deployment
```

### Database Backups

SQLite is stored in a persistent volume. The VPS setup script includes automated daily backups:

```bash
# Manual backup (VPS)
/opt/backups/backup-mythos.sh

# View backups
ls -la /opt/backups/

# Restore from backup
gunzip -c /opt/backups/mythos_20250115_030000.db.gz > /app/data/mythos.db
```

### Environment Variable Updates

```bash
# Fly.io
fly secrets set KEY=newvalue
# (auto-redeploys)

# Railway
railway variables --set KEY=newvalue

# DigitalOcean / VPS
# Edit .env file and restart:
# systemctl restart claude-mythos
```

---

## Troubleshooting

### App won't start

```bash
# Check logs
fly logs                    # Fly.io
docker logs mythos-backend  # Docker
journalctl -u claude-mythos # VPS

# Verify environment variables
curl https://your-app.com/health
# Check llm_available and whatsapp_configured flags
```

### Database issues

```bash
# Check if volume is mounted
docker exec mythos-backend ls -la /app/data/

# Check database file
docker exec mythos-backend sqlite3 /app/data/mythos.db ".tables"
```

### WhatsApp not working

1. Check Twilio credentials are set correctly
2. Verify webhook URL is accessible (not behind auth)
3. Check `/health` shows `whatsapp_configured: true`
4. Check logs for Twilio API errors
5. Ensure sandbox join message was sent

### High memory usage

```bash
# Reduce workers
fly secrets set WORKERS=2  # or 1 for low traffic

# Or upgrade plan
fly scale memory 2048      # 2GB RAM
```

---

## Security Checklist

- [ ] Never commit `.env` or secrets to git
- [ ] Use `fly secrets` / SSM / Render env vars for secrets
- [ ] Enable firewall (UFW) on VPS deployments
- [ ] Configure fail2ban for SSH protection
- [ ] Use HTTPS only (all configs redirect HTTP to HTTPS)
- [ ] Keep Docker images updated (`docker pull` regularly)
- [ ] Enable auto-updates on VPS (`unattended-upgrades`)
- [ ] Review CloudWatch / log access regularly
- [ ] Set up monitoring alerts for downtime

---

## CI/CD Pipeline

The GitHub Actions workflow (`.github/workflows/deploy.yml`) automatically:

1. **Tests** code on every push/PR
2. **Builds** Docker image
3. **Scans** for vulnerabilities (Trivy)
4. **Pushes** to GitHub Container Registry
5. **Deploys** to Fly.io on merge to main

Required GitHub secrets:

| Secret | Description |
|--------|-------------|
| `FLY_API_TOKEN` | Fly.io API token (`fly tokens create deploy`) |
| `RAILWAY_TOKEN` | Railway API token (optional) |

---

## Need Help?

- **Fly.io docs**: https://fly.io/docs/
- **Railway docs**: https://docs.railway.app/
- **Render docs**: https://render.com/docs
- **AWS ECS docs**: https://docs.aws.amazon.com/ecs/
- **Twilio WhatsApp**: https://www.twilio.com/docs/whatsapp

---

*Claude Mythos - Your AI Digital Marketing Agency in the Cloud*
