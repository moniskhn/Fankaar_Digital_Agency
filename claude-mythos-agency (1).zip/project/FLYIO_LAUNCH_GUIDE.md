# Deploy Claude Mythos to Fly.io — Step-by-Step Guide

---

## BEFORE YOU START: What You Need

| Item | Where to Get It | Time |
|------|----------------|------|
| Fly.io account | https://fly.io/app/sign-up | 2 min |
| flyctl (CLI tool) | `brew install flyctl` | 1 min |
| Anthropic API key | https://console.anthropic.com/ | 3 min |
| Twilio credentials | https://www.twilio.com/try-twilio | 5 min |
| Stripe account | https://dashboard.stripe.com/register | 3 min |

---

## STEP 1: Sign Up for Fly.io (2 minutes)

1. Go to **https://fly.io/app/sign-up**

2. You have 3 sign-up options:
   - **Sign up with GitHub** (fastest — click the GitHub button)
   - **Sign up with Google** (click Google button)
   - **Email + Password** (fill in the form)

3. If using GitHub:
   - Click **"Sign up with GitHub"**
   - GitHub opens — click **"Authorize flydotio"**
   - You'll be redirected back to Fly.io

4. Enter your **organization name** (this is your account name):
   - Suggestion: `claude-mythos-agency` or your name
   - This becomes part of your app URL

5. **Done.** You're now on the Fly.io dashboard.

---

## STEP 2: Install flyctl on Your Mac (1 minute)

Open Terminal on your Mac and run:

```bash
brew install flyctl
```

Wait for it to install, then verify:

```bash
fly version
```

You should see something like:
```
flyctl v0.3.x
```

**Now log in to Fly from your terminal:**

```bash
fly auth login
```

This will:
1. Open your browser
2. Show "Authorization successful"
3. Close the tab automatically

Back in Terminal, you'll see:
```
Successfully logged in as you@email.com
```

---

## STEP 3: Prepare Your Project Files

### A. Unzip the project

```bash
# Create a folder
mkdir ~/claude-mythos && cd ~/claude-mythos

# Move the downloaded zip here
# (If you downloaded to Downloads:)
mv ~/Downloads/claude-mythos-agency.zip .

# Extract
unzip claude-mythos-agency.zip

# Go into the project
cd project

# You should see these files:
# backend/  landing/  docker-compose.yml  fly.toml  start.sh  etc.
```

### B. Set up your environment file

```bash
cd backend
cp .env.example .env
```

Now edit `.env` with your real API keys:

```bash
# Use TextEdit
open -e .env
```

**Fill in ONLY these values (leave everything else as-is):**

```env
# ===== REQUIRED: AI Brain (Pick ONE) =====

# Option A: Anthropic Claude (BEST quality, RECOMMENDED)
LLM_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-api03-YOUR-REAL-KEY-HERE

# ===== REQUIRED: WhatsApp (CEO Daily Reports) =====
TWILIO_ACCOUNT_SID=AC-YOUR-REAL-SID-HERE
TWILIO_AUTH_TOKEN=YOUR-REAL-AUTH-TOKEN
TWILIO_WHATSAPP_NUMBER=+14155238886
OWNER_WHATSAPP_NUMBER=+971YOUR-REAL-PHONE-NUMBER

# ===== REQUIRED: Stripe (Payments) =====
STRIPE_SECRET_KEY=sk_test_YOUR-REAL-KEY
STRIPE_PUBLISHABLE_KEY=pk_test_YOUR-REAL-KEY
STRIPE_WEBHOOK_SECRET=whsec_YOUR-REAL-SECRET

# Create these in Stripe Dashboard first:
STRIPE_STARTER_PRICE_ID=price_YOUR-STARTER-ID
STRIPE_GROWTH_PRICE_ID=price_YOUR-GROWTH-ID
STRIPE_ENTERPRISE_PRICE_ID=price_YOUR-ENTERPRISE-ID
```

**Save the file** (Cmd+S in TextEdit).

---

## STEP 4: Create the App on Fly.io

Back in Terminal (in the `~/claude-mythos/project` folder):

```bash
# Make sure you're in the project folder
cd ~/claude-mythos/project

# Launch the app on Fly
fly launch
```

**What happens next:**

1. **"An existing fly.toml file was found"** → Type `y` and press Enter
   (This uses our pre-configured settings)

2. **"Choose app name"** → Press Enter to accept `claude-mythos-agency`
   (Or type a custom name if you prefer)

3. **"Choose a region"** → Pick a region closest to you:
   - `lhr` — London (Europe)
   - `iad` — Washington DC (US East)
   - `sjc` — San Jose (US West)
   - `hkg` — Hong Kong (Asia)
   - `sin` — Singapore (Asia)
   - `ams` — Amsterdam (Europe)
   - `bom` — Mumbai (Asia)
   - `fra` — Frankfurt (Europe)
   - `cdg` — Paris (Europe)
   - `syd` — Sydney (Oceania)
   - `nrt` — Tokyo (Asia)
   - `yyz` — Toronto (North America)
   - `dfw` — Dallas (US Central)
   - `mia` — Miami (US East)
   - `sea` — Seattle (US West)
   - `yul` — Montreal (North America)
   - `eze` — Buenos Aires (South America)
   - `gru` — Sao Paulo (South America)

   Type the 3-letter code and press Enter.

4. **"Would you like to set up a Postgresql database?"** → Type `N` and press Enter
   (We use SQLite which is simpler)

5. **"Would you like to set up an Upstash Redis database?"** → Type `N` and press Enter
   (Not needed for our setup)

6. **"Would you like to deploy now?"** → Type `N` and press Enter
   (We'll deploy AFTER setting secrets)

**You now have an app created on Fly.io but not yet deployed.**

---

## STEP 5: Set Your Secrets on Fly.io

**Secrets = your API keys. These are encrypted and stored securely by Fly.**

Run these commands ONE BY ONE (replace with your real keys):

```bash
# Anthropic (AI Brain)
fly secrets set ANTHROPIC_API_KEY="sk-ant-api03-YOUR-REAL-KEY-HERE"

# Twilio (WhatsApp)
fly secrets set TWILIO_ACCOUNT_SID="AC-YOUR-REAL-SID-HERE"
fly secrets set TWILIO_AUTH_TOKEN="YOUR-REAL-AUTH-TOKEN"
fly secrets set TWILIO_WHATSAPP_NUMBER="+14155238886"
fly secrets set OWNER_WHATSAPP_NUMBER="+971YOUR-REAL-PHONE"

# Stripe (Payments)
fly secrets set STRIPE_SECRET_KEY="sk_test_YOUR-REAL-KEY"
fly secrets set STRIPE_PUBLISHABLE_KEY="pk_test_YOUR-REAL-KEY"
fly secrets set STRIPE_WEBHOOK_SECRET="whsec_YOUR-REAL-SECRET"
fly secrets set STRIPE_STARTER_PRICE_ID="price_YOUR-STARTER-ID"
fly secrets set STRIPE_GROWTH_PRICE_ID="price_YOUR-GROWTH-ID"
fly secrets set STRIPE_ENTERPRISE_PRICE_ID="price_YOUR-ENTERPRISE-ID"

# Agency settings
fly secrets set AGENCY_NAME="Claude Mythos"
fly secrets set OWNER_NAME="Boss"
fly secrets set DAILY_REPORT_TIME="09:00"
fly secrets set DAILY_REPORT_TIMEZONE="UTC"
fly secrets set DATABASE_PATH="/app/data/mythos.db"
```

**To verify your secrets are set:**

```bash
fly secrets list
```

You should see all your secret names (values are hidden for security).

---

## STEP 6: Create a Volume (for Database Persistence)

Your agent data needs to survive app restarts. Create a persistent volume:

```bash
fly volumes create mythos_data --size 1 --region lhr
```

Replace `lhr` with the region you picked in Step 4.

You'll see:
```
Created volume: vol_xxxxxxxx in lhr
```

---

## STEP 7: DEPLOY! (The Big Moment)

Now deploy your agency to the internet:

```bash
fly deploy
```

**What you'll see:**

```
==> Building image
Sending build context to Docker daemon  125MB
Step 1/8 : FROM python:3.11-slim
...
==> Pushing image to fly
...
==> Creating release
Release v1 created
--> Deploying
...
```

Wait 2-3 minutes. When you see:

```
--> v1 deployed successfully
```

🎉 **YOUR AGENCY IS LIVE!**

---

## STEP 8: Verify Your Deployment

### A. Check the app is running

```bash
fly status
```

You should see:
```
App
  Name     = claude-mythos-agency
  Owner    = personal
  Version  = 1
  Status   = running
  Hostname = claude-mythos-agency.fly.dev

Machines
  ID              STATE   REGION  HEALTH CHECKS
  1234567890ab    started lhr     1 passing
```

### B. Open your live dashboard

```bash
fly open
```

This opens your browser to:
```
https://claude-mythos-agency.fly.dev
```

**You should see the Agency HQ dashboard** with all 23 agents.

### C. Test the API

```bash
# Test health endpoint
curl https://claude-mythos-agency.fly.dev/health

# Expected output:
# {"status":"healthy","version":"1.0.0","services":"all operational"}
```

### D. Test WhatsApp

```bash
# Trigger a test daily report
curl -X POST https://claude-mythos-agency.fly.dev/api/ceo/daily-report/send
```

Check your WhatsApp — you should get a message from Jon Snow within 30 seconds.

---

## STEP 9: Deploy Your Landing Page (Client-Facing)

Your landing page needs to be hosted separately (it's static HTML).

### Option A: Fly.io (Same Domain)

The landing page is already included in your Fly app. Visit:
```
https://claude-mythos-agency.fly.dev/landing/index.html
```

### Option B: Netlify (Free, Custom Domain)

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Deploy landing page
cd ~/claude-mythos/project/landing
netlify deploy --prod

# Follow the prompts:
# - "Create & configure a new site" → yes
# - Team → your name
# - Site name → claude-mythos-agency
# - You get: https://claude-mythos-agency.netlify.app
```

### Option C: Cloudflare Pages (Free)

```bash
# Install Wrangler
npm install -g wrangler

# Deploy
cd ~/claude-mythos/project/landing
wrangler pages deploy . --project-name=claude-mythos

# You get: https://claude-mythos.pages.dev
```

---

## STEP 10: Connect Your Domain (Optional)

### Using Fly.io (Custom Domain)

1. Buy a domain (Namecheap, GoDaddy, Google Domains)
2. In your domain DNS settings, add a CNAME:
   - Name: `www` or `@`
   - Value: `claude-mythos-agency.fly.dev`
3. On Fly, run:
   ```bash
   fly certs create www.yourdomain.com
   ```
4. Wait 5-10 minutes for SSL certificate

### Using Netlify (Custom Domain)

1. In Netlify dashboard, go to your site → Domain settings
2. Click "Add custom domain"
3. Enter your domain
4. Follow Netlify's DNS instructions

---

## COMPLETE DEPLOYMENT CHECKLIST

| Step | Action | Status |
|------|--------|--------|
| ☐ | Sign up for Fly.io | |
| ☐ | Install flyctl (`brew install flyctl`) | |
| ☐ | Log in to Fly (`fly auth login`) | |
| ☐ | Unzip project files | |
| ☐ | Get Anthropic API key | |
| ☐ | Get Twilio credentials | |
| ☐ | Get Stripe keys + create products | |
| ☐ | Fill in `.env` file with real keys | |
| ☐ | Run `fly launch` | |
| ☐ | Pick region | |
| ☐ | Set all secrets with `fly secrets set` | |
| ☐ | Create volume with `fly volumes create` | |
| ☐ | Run `fly deploy` | |
| ☐ | Verify with `fly status` | |
| ☐ | Open dashboard with `fly open` | |
| ☐ | Test WhatsApp report | |
| ☐ | Deploy landing page (Netlify/Cloudflare) | |
| ☐ | (Optional) Connect custom domain | |

---

## COMMON ISSUES & FIXES

### Issue: "flyctl not found"
```bash
# Reinstall
brew reinstall flyctl

# Or download directly
curl -L https://fly.io/install.sh | sh
```

### Issue: "Not authorized"
```bash
# Log in again
fly auth login
```

### Issue: "No such app" or "App not found"
```bash
# Make sure you're in the project folder
cd ~/claude-mythos/project

# Check your fly.toml exists
cat fly.toml

# If needed, recreate the app
fly apps create claude-mythos-agency
```

### Issue: "Failed to fetch an image or build from source"
```bash
# Make sure Docker Desktop is running
open -a Docker

# Wait 30 seconds for Docker to start
# Then try again
fly deploy
```

### Issue: "Health check failing"
```bash
# Check logs
fly logs

# Common cause: missing secrets
# Make sure ALL required secrets are set
fly secrets list
```

### Issue: "Database error" or "Cannot find database"
```bash
# Make sure volume exists
fly volumes list

# If no volume, create one
fly volumes create mythos_data --size 1 --region YOUR-REGION

# Then redeploy
fly deploy
```

---

## YOUR LIVE URLs AFTER DEPLOYMENT

| Service | URL | What It Does |
|---------|-----|--------------|
| **Dashboard** | `https://claude-mythos-agency.fly.dev` | Your internal agency HQ |
| **API** | `https://claude-mythos-agency.fly.dev/api/` | Backend API endpoints |
| **Health** | `https://claude-mythos-agency.fly.dev/health` | System health check |
| **Landing** | `https://claude-mythos-agency.netlify.app` | Client-facing page (if using Netlify) |
| **Stripe Webhook** | `https://claude-mythos-agency.fly.dev/webhook/stripe` | Stripe payment webhooks |
| **WhatsApp Webhook** | `https://claude-mythos-agency.fly.dev/webhook/whatsapp` | Twilio WhatsApp webhooks |

---

## DAILY COMMANDS YOU'LL USE

```bash
# View live logs (watch your agents work)
fly logs

# Restart the app
fly apps restart claude-mythos-agency

# Scale up (more CPU/memory)
fly scale vm shared-cpu-4x --memory 4096

# Add more regions (global deployment)
fly regions add fra  # Frankfurt
fly regions add sin  # Singapore

# Backup your database
fly ssh console -C "sqlite3 /app/data/mythos.db .dump" > backup.sql

# Update code and redeploy
fly deploy
```

---

## COST ON FLY.IO

| Component | Cost/Month |
|-----------|-----------|
| App (shared-cpu-2x, 2GB RAM) | ~$5 |
| Volume (1GB persistent storage) | ~$0.15 |
| Bandwidth (first 160GB) | Free |
| **Total hosting** | **~$5.15/month** |

**Plus API costs:**
- Anthropic: ~$0.50-2/day per active client
- Twilio: ~$0.005/message (~$0.15/month for daily reports)
- Stripe: 2.9% + $0.30 per transaction (only when you get paid)

---

## SUPPORT

**Fly.io docs:** https://fly.io/docs/
**Fly.io community:** https://community.fly.io/
**Fly.io status:** https://status.fly.io/

---

## YOU DID IT!

Your 23 AI employees are now running on the internet 24/7.

**Next step:** Share your landing page URL on LinkedIn, Twitter, and with your network. Get your first client.

*"An agency is only as good as its last campaign. Let's make it legendary."* — Jon Snow, CEO
