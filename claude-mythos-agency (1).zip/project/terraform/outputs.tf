# Claude Mythos - Terraform Outputs

output "load_balancer_dns" {
  description = "DNS name of the Application Load Balancer"
  value       = aws_lb.main.dns_name
}

output "app_url" {
  description = "Application URL (use this for webhook configuration)"
  value       = var.domain_name != "" ? "https://${var.domain_name}" : "http://${aws_lb.main.dns_name}"
}

output "ecr_repository_url" {
  description = "ECR repository URL for Docker images"
  value       = aws_ecr_repository.backend.repository_url
}

output "ecs_cluster_name" {
  description = "ECS cluster name"
  value       = aws_ecs_cluster.main.name
}

output "ecs_service_name" {
  description = "ECS service name"
  value       = aws_ecs_service.backend.name
}

output "cloudwatch_log_group" {
  description = "CloudWatch log group for viewing logs"
  value       = aws_cloudwatch_log_group.backend.name
}

output "ssm_parameter_prefix" {
  description = "Prefix for SSM parameters (secrets)"
  value       = "/${var.project_name}"
}

output "ssh_command" {
  description = "Not applicable for Fargate (serverless)"
  value       = "N/A - ECS Fargate is serverless, use: aws logs tail /ecs/${var.project_name}-backend --follow"
}

output "cost_estimate" {
  description = "Estimated monthly cost"
  value       = "~$30-50/month (Fargate + ALB + EFS + Data Transfer)"
}

output "health_check_url" {
  description = "Health check endpoint"
  value       = var.domain_name != "" ? "https://${var.domain_name}/health" : "http://${aws_lb.main.dns_name}/health"
}

output "webhook_url" {
  description = "WhatsApp webhook URL (configure in Twilio)"
  value       = var.domain_name != "" ? "https://${var.domain_name}/webhook/whatsapp" : "http://${aws_lb.main.dns_name}/webhook/whatsapp"
}

output "docs_url" {
  description = "API documentation URL"
  value       = var.domain_name != "" ? "https://${var.domain_name}/docs" : "http://${aws_lb.main.dns_name}/docs"
}
