# Claude Mythos - Terraform Variables

variable "project_name" {
  description = "Name of the project"
  type        = string
  default     = "claude-mythos"
}

variable "environment" {
  description = "Environment name"
  type        = string
  default     = "production"
}

variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

# ── Domain ─────────────────────────────────────────────────────

variable "domain_name" {
  description = "Domain name for the application (e.g., mythos.example.com)"
  type        = string
  default     = ""
}

variable "hosted_zone_id" {
  description = "Route 53 hosted zone ID (leave empty to skip DNS)"
  type        = string
  default     = ""
}

variable "create_hosted_zone" {
  description = "Create a new Route 53 hosted zone"
  type        = bool
  default     = false
}

# ── ECS Task Configuration ─────────────────────────────────────

variable "task_cpu" {
  description = "CPU units for the ECS task (256 = 0.25 vCPU, 512 = 0.5 vCPU, 1024 = 1 vCPU)"
  type        = string
  default     = "512"
}

variable "task_memory" {
  description = "Memory for the ECS task in MB"
  type        = string
  default     = "1024"
}

variable "gunicorn_workers" {
  description = "Number of Gunicorn workers"
  type        = number
  default     = 2
}

variable "desired_count" {
  description = "Desired number of tasks running"
  type        = number
  default     = 1
}

variable "min_count" {
  description = "Minimum number of tasks (auto-scaling)"
  type        = number
  default     = 1
}

variable "max_count" {
  description = "Maximum number of tasks (auto-scaling)"
  type        = number
  default     = 3
}

variable "cpu_target" {
  description = "Target CPU utilization for auto-scaling"
  type        = number
  default     = 70
}

variable "memory_target" {
  description = "Target memory utilization for auto-scaling"
  type        = number
  default     = 70
}

# ── Application Settings ───────────────────────────────────────

variable "agency_name" {
  description = "Name of the AI agency"
  type        = string
  default     = "Claude Mythos"
}

variable "llm_provider" {
  description = "LLM provider (anthropic, openai, ollama)"
  type        = string
  default     = "anthropic"
}

variable "anthropic_model" {
  description = "Anthropic model to use"
  type        = string
  default     = "claude-3-5-sonnet-20241022"
}

variable "log_level" {
  description = "Application log level"
  type        = string
  default     = "INFO"
}

# ── Secrets ────────────────────────────────────────────────────
# These are passed via terraform.tfvars (never commit secrets!)

variable "anthropic_api_key" {
  description = "Anthropic API key"
  type        = string
  default     = ""
  sensitive   = true
}

variable "openai_api_key" {
  description = "OpenAI API key"
  type        = string
  default     = ""
  sensitive   = true
}

variable "twilio_account_sid" {
  description = "Twilio Account SID"
  type        = string
  default     = ""
  sensitive   = true
}

variable "twilio_auth_token" {
  description = "Twilio Auth Token"
  type        = string
  default     = ""
  sensitive   = true
}

variable "twilio_whatsapp_number" {
  description = "Twilio WhatsApp sender number"
  type        = string
  default     = ""
  sensitive   = true
}

variable "owner_whatsapp_number" {
  description = "Owner WhatsApp number for reports"
  type        = string
  default     = ""
  sensitive   = true
}

# ── Logging ────────────────────────────────────────────────────

variable "log_retention_days" {
  description = "CloudWatch log retention in days"
  type        = number
  default     = 30
}
