# GitHub Actions Workflows

## `deploy.yml` - Main CI/CD Pipeline
Triggered on push to main:
1. Runs Python tests
2. Builds Docker image and pushes to GHCR
3. Deploys to Fly.io (production)
4. Deploys to Railway (production)
5. Runs security scan with Trivy

## `deploy-railway.yml` - Standalone Railway Deploy
Manual or auto-deploy to Railway.app.

## `deploy-render.yml` - Render Health Check
Verifies Render deployment is healthy after push.

## Required Secrets

Set these in your GitHub repository settings:

| Secret | How to Get |
|--------|-----------|
| `FLY_API_TOKEN` | `fly tokens create deploy` |
| `RAILWAY_TOKEN` | Railway Dashboard > Tokens |
| `RENDER_APP_URL` | Your Render app URL |
