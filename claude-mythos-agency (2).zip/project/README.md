# Claude Mythos — AI Digital Marketing Agency

**Claude Mythos** is a locally-run, fully-contained AI digital marketing agency that operates entirely on your MacBook. It features 23 specialized AI employees (each with unique personalities, skills, and roles) orchestrated by an AI CEO who reports to you daily via WhatsApp.

![Dashboard Preview](https://2daxzhpzeiguo.kimi.page)

---

## What You Get

### 23 AI Employees (Game of Thrones Themed)

| # | Agent | Role | What They Do |
|---|-------|------|-------------|
| 1 | **Sandor** | Sales | Lead qualification, closing deals |
| 2 | **Sansa** | PR | Reputation management, media, crisis handling |
| 3 | **Rhaegar** | Design | Brand identity, creative, visuals |
| 4 | **Gendry** | Dev | Build integrations, technical infrastructure |
| 5 | **Tywin** | Finance | Budgets, invoicing, cash flow |
| 6 | **Olenna** | HR | Hiring, onboarding, team culture |
| 7 | **Stannis** | Legal | Contracts, compliance, risk |
| 8 | **Brienne** | Operations | Project management, deadlines, QA |
| 9 | **Podrick** | Support | Client care, ticket resolution |
| 10 | **Arya** | Research | Market intelligence, competitive analysis |
| 11 | **Bran** | Strategy | Growth plans, opportunity identification |
| 12 | **Cersei** | Negotiation | Vendor deals, cost optimization |
| 13 | **Davos** | Communication | Client relations, meetings, diplomacy |
| 14 | **Jorah** | Loyalty | Client retention, upsell campaigns |
| 15 | **Jon** | CEO | Commander, decision maker, **daily reports to you** |
| 16 | **Tyrion** | Writer | Copywriting, content creation |
| 17 | **Sandoq** | SEO | Search optimization, keywords, rankings |
| 18 | **Missandei** | Social | Social media management, community building |
| 19 | **Bronn** | AdCopy | Ad creation, headlines, conversion optimization |
| 20 | **Samwell** | Analytics | Data analysis, insights, performance reports |
| 21 | **Margaery** | Email | Email campaigns, sequences, newsletters |
| 22 | **Petyr** | Reporting | Dashboards, status updates, metrics |
| 23 | **Greyworm** | Landing | CRO, A/B testing, landing page optimization |

### CEO Daily WhatsApp Reports

Jon (CEO) compiles a daily briefing and sends it to your WhatsApp every morning:

```
CLAUDE MYTHOS — DAILY REPORT
May 2, 2026

TODAY'S HIGHLIGHTS
✅ Campaign "Summer Launch" moved to LIVE
✅ Sandor closed 2 new qualified leads
⚠️ Stannis flagged contract issue with Client X

TEAM UPDATES
• Tyrion: Completed 8 social captions for Dubai client
• Missandei: Community grew +12% this week
• Sandoq: SEO rankings up 3 positions

CAMPAIGNS
LIVE (3) | IN CREATION (2) | NEEDS ATTENTION (1)

NEEDS YOUR INPUT:
→ Approve budget increase ($500) for Bronn's ad test?
Reply with decisions — I'll execute.
```

### Regional Intelligence Engine

Your agency understands local markets worldwide:
- **Cultural awareness** — Adapts messaging to local customs and taboos
- **Platform preferences** — Knows which social platforms dominate each region
- **Optimal timing** — Calculates best posting times per timezone
- **Localized CTAs** — Uses culturally-relevant call-to-action phrases
- **Audience personas** — Builds profiles for target demographics per region

### Full Campaign Lifecycle

1. **Brief** — Submit campaign requirements
2. **Strategy** — Bran + Arya create the plan
3. **Creation** — Tyrion + Rhaegar + Missandei build assets
4. **Review** — Jon + Brienne QA everything
5. **Approval** — You approve via dashboard or WhatsApp
6. **Live** — Bronn + Greyworm + Missandei execute
7. **Reporting** — Samwell + Petyr compile results
8. **Optimization** — Jorah follows up, learnings captured

---

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     YOU (Owner)                              │
│              WhatsApp ← → Web Dashboard                      │
└──────────────┬────────────────────────────────┬─────────────┘
               │                                │
    ┌──────────▼──────────┐      ┌──────────────▼──────────┐
    │   Twilio WhatsApp   │      │  React Dashboard        │
    │   API               │      │  (localhost:3000)       │
    └──────────┬──────────┘      └──────────────┬──────────┘
               │                                │
               └────────────────┬───────────────┘
                                │
                    ┌───────────▼───────────┐
                    │   FastAPI Backend     │
                    │   (localhost:8000)    │
                    │                       │
                    │  ┌─────────────────┐  │
                    │  │  23 AI Agents   │  │
                    │  │  SQLite Memory  │  │
                    │  │  Task Router    │  │
                    │  │  Campaign Engine│  │
                    │  │  Regional Intel │  │
                    │  └─────────────────┘  │
                    └───────────────────────┘
```

---

## MacBook Setup Guide

### Prerequisites

- macOS 12+ (Monterey or newer)
- [Docker Desktop](https://www.docker.com/products/docker-desktop) installed
- 8GB+ RAM recommended (16GB for local LLMs)
- Python 3.11+ (for local development)

### Quick Start

```bash
# 1. Clone or download the project
cd claude-mythos

# 2. Configure your environment
cp backend/.env.example .env
nano .env  # Edit with your API keys

# 3. Start the agency
./start.sh
```

The dashboard will be available at **http://localhost:3000**

### LLM Configuration

Choose your AI backend:

**Option A: Moonshot AI / Kimi (RECOMMENDED — CHEAPEST!)**
```env
LLM_PROVIDER=moonshot
MOONSHOT_API_KEY=sk-your-key-here
MOONSHOT_MODEL=kimi-latest
```
- Get key: https://platform.moonshot.ai/
- Cost: ~$0.50-2 per million tokens (5-10x cheaper than Anthropic)
- Quality: Same as Claude for marketing tasks

**Option B: Anthropic Claude (Expensive)
```env
LLM_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-your-key-here
```
- Cost: ~$3-15 per million tokens

**Option C: OpenAI**
```env
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-your-key-here
```

**Option C: Local LLM via Ollama (Fully Private)**
```bash
# Install Ollama
brew install ollama

# Pull a model
ollama pull llama3.2

# In .env
LLM_PROVIDER=ollama
OLLAMA_HOST=host.docker.internal:11434
OLLAMA_MODEL=llama3.2
```

### WhatsApp Setup

1. Create a [Twilio account](https://www.twilio.com/try-twilio)
2. Activate the WhatsApp Sandbox
3. Add these to your `.env`:
```env
TWILIO_ACCOUNT_SID=ACxxx
TWILIO_AUTH_TOKEN=xxx
TWILIO_WHATSAPP_NUMBER=+1415xxx
OWNER_WHATSAPP_NUMBER=+971xxx
```

---

## Project Structure

```
claude-mythos/
├── backend/
│   ├── app/
│   │   ├── agents/              # 23 AI employee definitions
│   │   │   ├── registry.py      # All agent profiles & prompts
│   │   │   ├── base_agent.py    # Agent base class
│   │   │   └── jon_ceo.py       # CEO orchestrator
│   │   ├── core/
│   │   │   ├── config.py        # Settings
│   │   │   ├── database.py      # SQLite models
│   │   │   ├── models.py        # Pydantic schemas
│   │   │   ├── memory.py        # Agent memory
│   │   │   └── orchestrator.py  # Task routing
│   │   ├── services/
│   │   │   ├── llm_client.py    # LLM abstraction
│   │   │   ├── whatsapp.py      # Twilio integration
│   │   │   ├── regional_intel.py # Regional research
│   │   │   ├── campaign_engine.py # Campaign lifecycle
│   │   │   └── content_calendar.py # Scheduling
│   │   ├── api/
│   │   │   └── router.py        # All API endpoints
│   │   └── main.py              # FastAPI entry
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── components/          # Layout, Sidebar, TopBar
│   │   ├── pages/               # All 6 dashboard pages
│   │   ├── data/                # Mock data (23 agents, campaigns, etc.)
│   │   └── ...
│   └── dist/                    # Production build
├── docker-compose.yml
├── nginx.conf
├── start.sh
├── stop.sh
└── README.md
```

---

## API Reference

### Agents
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/agents` | List all 23 employees |
| GET | `/api/agents/{id}` | Get specific agent |
| GET | `/api/agents/{id}/activity` | Agent activity log |
| POST | `/api/agents/{id}/assign` | Assign task to agent |

### Campaigns
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/campaigns` | List campaigns |
| POST | `/api/campaigns` | Create campaign |
| GET | `/api/campaigns/{id}` | Campaign detail |
| PUT | `/api/campaigns/{id}/phase` | Advance phase |

### CEO
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/ceo/daily-report` | Generate report |
| POST | `/api/ceo/daily-report/send` | Send via WhatsApp |
| POST | `/api/ceo/message` | Message Jon |

### Regional Intel
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/regional/{region}` | Region profile |
| GET | `/api/regional/{region}/posting-times` | Best times |
| GET | `/api/regional/{region}/ctas` | Local CTAs |

---

## Dashboard Pages

| Page | Route | What You'll See |
|------|-------|-----------------|
| **Agency HQ** | `/` | Employee grid, live activity, stats, quick actions |
| **Agent Directory** | `/#/agents` | All 23 agents with profiles, search, filters |
| **Campaign Command** | `/#/campaigns` | Kanban board, creation wizard, calendar view |
| **CEO Reports** | `/#/ceo-reports` | Daily reports + chat with Jon |
| **Regional Intel** | `/#/regional` | Interactive map, regional profiles, posting times |
| **Settings** | `/#/settings` | WhatsApp, LLM, branding, notifications |

---

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `LLM_PROVIDER` | Yes | `anthropic`, `openai`, or `ollama` |
| `ANTHROPIC_API_KEY` | If using Anthropic | Your Claude API key |
| `TWILIO_ACCOUNT_SID` | For WhatsApp | Twilio Account SID |
| `TWILIO_AUTH_TOKEN` | For WhatsApp | Twilio Auth Token |
| `OWNER_WHATSAPP_NUMBER` | For WhatsApp | Your phone number |
| `OWNER_NAME` | No | Your title (default: "Lord Commander") |
| `DAILY_REPORT_TIME` | No | When Jon texts you (default: 09:00) |

---

## Commands

```bash
# Start everything
./start.sh

# Stop everything
./stop.sh

# View backend logs
docker-compose logs -f backend

# Restart just the backend
docker-compose restart backend

# Shell into backend
docker-compose exec backend bash

# Run backend locally (without Docker)
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload

# Rebuild after code changes
docker-compose build backend
```

---

## Tech Stack

**Backend:**
- FastAPI (Python) — High-performance API
- SQLAlchemy + SQLite — Persistent storage
- Twilio — WhatsApp messaging
- Ollama/Anthropic/OpenAI — LLM inference
- APScheduler — Daily report scheduling

**Frontend:**
- React 19 + TypeScript
- Tailwind CSS + shadcn/ui
- Framer Motion — Animations
- Recharts — Data visualization
- Vite — Build tooling

---

## License

MIT — Built with AI, for humans who want their own AI agency.

*"When you play the game of marketing, you win or you learn. There is no middle ground."* — Jon Snow, probably.
